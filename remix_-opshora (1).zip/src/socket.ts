import { io } from 'socket.io-client';

// Connect to the same host and port as the server
export const socket = io();
