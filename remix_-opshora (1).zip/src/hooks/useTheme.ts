import { useState, useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreError';

export interface ThemeConfig {
  brandName: string;
  brandImage: string;
  primaryColor: string;
  secondaryColor: string;
}

export function useTheme() {
  const [theme, setTheme] = useState<ThemeConfig>({
    brandName: 'Opshora',
    brandImage: '',
    primaryColor: '#2563eb', // Default blue-600
    secondaryColor: '#1e40af', // Default blue-800
  });

  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'settings', 'brandConfig'), (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        const primary = data.primaryColor || '#2563eb';
        const secondary = data.secondaryColor || '#1e40af';
        
        setTheme({
          brandName: data.name || 'Opshora',
          brandImage: data.brandImage || '',
          primaryColor: primary,
          secondaryColor: secondary,
        });

        // Update CSS variables
        document.documentElement.style.setProperty('--primary-color', primary);
        document.documentElement.style.setProperty('--secondary-color', secondary);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/brandConfig');
    });

    return () => unsubscribe();
  }, []);

  return theme;
}
