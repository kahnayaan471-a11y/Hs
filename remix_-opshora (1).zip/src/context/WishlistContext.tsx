import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { toast } from 'sonner';
import { socket } from '../socket';

interface WishlistContextType {
  wishlistItems: Product[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: number) => void;
  isInWishlist: (productId: number) => boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [wishlistItems, setWishlistItems] = useState<Product[]>(() => {
    const saved = localStorage.getItem('wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    try {
      localStorage.setItem('wishlist', JSON.stringify(wishlistItems));
    } catch (error) {
      console.error('Failed to save wishlist to localStorage:', error);
      // Fallback: try to save a simplified version
      try {
        const simplified = wishlistItems.map(item => ({ id: item.id }));
        localStorage.setItem('wishlist', JSON.stringify(simplified));
      } catch (e) {
        console.error('Even simplified wishlist save failed');
      }
    }
  }, [wishlistItems]);

  // Listen to product updates to remove deleted products from wishlist
  useEffect(() => {
    const handleProductsUpdate = (updatedProducts: Product[]) => {
      setWishlistItems(prevItems => {
        const productIds = new Set(updatedProducts.map(p => p.id));
        const filteredItems = prevItems.filter(item => productIds.has(item.id));
        return filteredItems;
      });
    };

    const handleInitialData = (data: { products: Product[] }) => {
      handleProductsUpdate(data.products);
    };

    socket.on('initial_data', handleInitialData);
    socket.on('products_update', handleProductsUpdate);

    return () => {
      socket.off('initial_data', handleInitialData);
      socket.off('products_update', handleProductsUpdate);
    };
  }, []);

  const addToWishlist = (product: Product) => {
    setWishlistItems(prev => {
      if (prev.find(item => item.id === product.id)) return prev;
      toast.success('Added to Wishlist!');
      return [...prev, product];
    });
  };

  const removeFromWishlist = (productId: number) => {
    setWishlistItems(prev => {
      toast.success('Removed from Wishlist');
      return prev.filter(item => item.id !== productId);
    });
  };

  const isInWishlist = (productId: number) => {
    return wishlistItems.some(item => item.id === productId);
  };

  return (
    <WishlistContext.Provider value={{ wishlistItems, addToWishlist, removeFromWishlist, isInWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
}
