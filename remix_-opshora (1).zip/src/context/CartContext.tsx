import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Product, Order, Address } from '../types';
import { db, auth } from '../firebase';
import { collection, addDoc, onSnapshot, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { toast } from 'sonner';
import { handleFirestoreError, OperationType } from '../utils/firestoreError';
import { socket } from '../socket';

interface CartContextType {
  cartItems: CartItem[];
  orders: Order[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  placeOrder: (address: Address, paymentMethod: string, details?: { utr?: string; isReselling?: boolean; profitMargin?: number }) => void;
  cartCount: number;
  cartTotal: number;
  promoDiscount: number;
  applyPromoCode: (discount: number, type: string, code: string) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [appliedPromoCode, setAppliedPromoCode] = useState<string | null>(null);

  // Listen to product updates to remove deleted products from cart
  useEffect(() => {
    const handleProductsUpdate = (updatedProducts: Product[]) => {
      setCartItems(prevItems => {
        const productIds = new Set(updatedProducts.map(p => p.id));
        const filteredItems = prevItems.filter(item => productIds.has(item.id));
        
        if (filteredItems.length < prevItems.length) {
          toast.error('Some items in your cart are no longer available and have been removed.');
        }
        
        return filteredItems;
      });
    };

    const handleInitialData = (data: { products: Product[] }) => {
      handleProductsUpdate(data.products);
    };

    socket.on('initial_data', handleInitialData);
    socket.on('products_update', handleProductsUpdate);

    return () => {
      socket.off('initial_data', handleInitialData);
      socket.off('products_update', handleProductsUpdate);
    };
  }, []);

  // Load orders from Firestore on auth change
  useEffect(() => {
    if (!auth.currentUser) {
      setOrders([]);
      return;
    }

    const ordersQuery = query(
      collection(db, 'orders'),
      where('userId', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(ordersQuery, (snapshot) => {
      const fetchedOrders = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        date: doc.data().createdAt?.toDate()?.toISOString() || new Date().toISOString()
      })) as Order[];
      setOrders(fetchedOrders);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'orders'));

    return () => unsubscribe();
  }, [auth.currentUser]);

  // Real-time promo code validation
  useEffect(() => {
    if (!appliedPromoCode) return;

    const q = query(
      collection(db, 'promoCodes'),
      where('code', '==', appliedPromoCode),
      where('active', '==', true)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (snapshot.empty) {
        setPromoDiscount(0);
        setAppliedPromoCode(null);
        toast.error('The applied promo code is no longer valid.');
      } else {
        const promoData = snapshot.docs[0].data();
        const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
        if (promoData.type === 'percentage') {
          setPromoDiscount(subtotal * (promoData.discount / 100));
        } else {
          setPromoDiscount(promoData.discount);
        }
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, 'promoCodes'));

    return () => unsubscribe();
  }, [appliedPromoCode, cartItems]);

  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existingItem = prev.find(item => item.id === product.id);
      if (existingItem) {
        return prev.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems(prev => 
      prev.map(item => 
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCartItems([]);
    setPromoDiscount(0);
    setAppliedPromoCode(null);
  };

  const applyPromoCode = (discount: number, type: string, code: string) => {
    setAppliedPromoCode(code.toUpperCase());
    const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    if (type === 'percentage') {
      setPromoDiscount(subtotal * (discount / 100));
    } else {
      setPromoDiscount(discount);
    }
  };

  const placeOrder = async (address: Address, paymentMethod: string, details?: { utr?: string; isReselling?: boolean; profitMargin?: number; resellerEmail?: string; resellerPassword?: string; realPrice?: number }) => {
    if (!auth.currentUser) {
      toast.error('Please sign in to place an order');
      return;
    }
    
    // Clean address to avoid potential circular structures or non-serializable data
    const cleanAddress = {
      fullName: String(address.fullName || ''),
      phone: String(address.phone || ''),
      pincode: String(address.pincode || ''),
      houseNo: String(address.houseNo || ''),
      area: String(address.area || ''),
      landmark: String(address.landmark || ''),
      city: String(address.city || ''),
      state: String(address.state || ''),
      type: address.type || 'home',
      isDefault: !!address.isDefault
    };

    try {
      const orderData = {
        userId: auth.currentUser.uid,
        userEmail: auth.currentUser.email,
        userName: auth.currentUser.displayName,
        items: cartItems.map(item => ({
          id: Number(item.id),
          title: String(item.title || ''),
          price: Number(item.price || 0),
          quantity: Number(item.quantity || 1),
          image: String(item.image || '')
        })),
        total: Number(cartTotal + (details?.profitMargin || 0)),
        status: 'Ordered',
        address: cleanAddress,
        paymentMethod: String(paymentMethod || ''),
        utr: String(details?.utr || ''),
        isReselling: !!details?.isReselling,
        profitMargin: Number(details?.profitMargin || 0),
        resellerEmail: String(details?.resellerEmail || ''),
        resellerPassword: String(details?.resellerPassword || ''),
        realPrice: Number(details?.realPrice || 0),
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'orders'), orderData);
      clearCart();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'orders');
      toast.error('Failed to place order. Please try again.');
    }
  };

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const cartTotal = Math.max(0, subtotal - promoDiscount);

  return (
    <CartContext.Provider value={{ 
      cartItems, 
      orders,
      addToCart, 
      removeFromCart, 
      updateQuantity, 
      clearCart, 
      placeOrder,
      cartCount, 
      cartTotal,
      promoDiscount,
      applyPromoCode
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
