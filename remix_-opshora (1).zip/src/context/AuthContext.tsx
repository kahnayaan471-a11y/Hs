import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { socket } from '../socket';
import { toast } from 'sonner';

interface User {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  role?: string;
}

interface ResellerUser {
  email: string;
  name?: string;
}

interface AuthContextType {
  user: User | null;
  resellerUser: ResellerUser | null;
  login: () => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (email: string, password: string, name: string) => Promise<void>;
  createAccountManager: (email: string, password: string, name: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  resellerLogin: (email: string) => void;
  resellerLogout: () => void;
  isLoggedIn: boolean;
  isResellerLoggedIn: boolean;
  isAuthReady: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [resellerUser, setResellerUser] = useState<ResellerUser | null>(() => {
    const saved = localStorage.getItem('resellerUser');
    return saved ? JSON.parse(saved) : null;
  });
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      try {
        if (firebaseUser) {
          // Check if user exists in Firestore, if not create it
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (!userDoc.exists()) {
            const userData = {
              uid: firebaseUser.uid,
              name: firebaseUser.displayName || 'User',
              email: firebaseUser.email || '',
              photoURL: firebaseUser.photoURL || '',
              role: firebaseUser.email === 'kahnayaan471@gmail.com' ? 'admin' : 'user',
              createdAt: serverTimestamp()
            };
            await setDoc(userDocRef, userData);
            setUser(userData as User);
          } else {
            const data = userDoc.data();
            // Force admin role for owner email if not already set
            if (firebaseUser.email === 'kahnayaan471@gmail.com' && data.role !== 'admin') {
              await setDoc(userDocRef, { role: 'admin' }, { merge: true });
              data.role = 'admin';
            }
            setUser(data as User);
          }
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Auth state change error:', error);
      } finally {
        setIsAuthReady(true);
      }
    });

    return () => unsubscribe();
  }, []);

  // Real-time reseller status check
  useEffect(() => {
    if (!resellerUser) return;

    const handleResellersUpdate = (resellers: any[]) => {
      const currentReseller = resellers.find(r => r.email === resellerUser.email);
      if (!currentReseller || currentReseller.isBanned) {
        resellerLogout();
        toast.error('Your reseller access has been revoked or your account is banned.');
      }
    };

    socket.on('resellers_update', handleResellersUpdate);
    
    return () => {
      socket.off('resellers_update', handleResellersUpdate);
    };
  }, [resellerUser]);

  const login = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') {
        console.log('User closed the login popup.');
      } else {
        console.error('Login failed:', error);
        throw error;
      }
    }
  };

  const loginWithEmail = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      console.error('Email login failed:', error);
      throw error;
    }
  };

  const registerWithEmail = async (email: string, password: string, name: string) => {
    try {
      const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(firebaseUser, { displayName: name });
      
      // The onAuthStateChanged listener will handle Firestore creation
    } catch (error) {
      console.error('Email registration failed:', error);
      throw error;
    }
  };

  const createAccountManager = async (username: string, password: string, name: string) => {
    try {
      // Construct a dummy email from username
      const email = `${username.toLowerCase().replace(/\s+/g, '')}@accountmanager.local`;
      
      // Create user in Firebase Auth
      const { user: firebaseUser } = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(firebaseUser, { displayName: name });
      
      // Create user document in Firestore with 'account_manager' role
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      await setDoc(userDocRef, {
        uid: firebaseUser.uid,
        name: name,
        email: email,
        username: username,
        role: 'account_manager',
        createdAt: serverTimestamp()
      });
      
      toast.success('Account Manager created successfully');
    } catch (error) {
      console.error('Account Manager creation failed:', error);
      throw error;
    }
  };

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      console.error('Password reset failed:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout failed:', error);
      throw error;
    }
  };

  const resellerLogin = (email: string) => {
    const reseller = { email };
    setResellerUser(reseller);
    localStorage.setItem('resellerUser', JSON.stringify(reseller));
  };

  const resellerLogout = () => {
    setResellerUser(null);
    localStorage.removeItem('resellerUser');
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      resellerUser,
      login, 
      loginWithEmail, 
      registerWithEmail, 
      createAccountManager,
      resetPassword,
      logout, 
      resellerLogin,
      resellerLogout,
      isLoggedIn: !!user, 
      isResellerLoggedIn: !!resellerUser,
      isAuthReady 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
