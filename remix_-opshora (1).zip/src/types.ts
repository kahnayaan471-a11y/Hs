export interface Review {
  id: string;
  userName: string;
  userPhoto?: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: number;
  title: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  images?: string[];
  prime: boolean;
  categoryId?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Address {
  fullName: string;
  phone: string;
  pincode: string;
  houseNo: string;
  area: string;
  landmark?: string;
  city: string;
  state: string;
  type?: 'home' | 'work';
  isDefault?: boolean;
}

export interface Category {
  id: string;
  name: string;
  image: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'staff' | 'user' | 'account_manager';
  isBanned?: boolean;
  createdAt: any;
}

export interface Order {
  id: string;
  userId: string;
  userEmail: string;
  items: CartItem[];
  total: number;
  date: string;
  status: 'Ordered' | 'Shipping' | 'Out for Delivery' | 'Delivered' | 'Cancelled';
  address: Address;
  paymentMethod: string;
  paymentDetails?: {
    utr?: string;
  };
  isReselling?: boolean;
  profitMargin?: number;
  resellerEmail?: string;
  resellerPassword?: string;
  realPrice?: number;
}
