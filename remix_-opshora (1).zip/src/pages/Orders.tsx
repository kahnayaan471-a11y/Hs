import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, ChevronRight, ChevronLeft, MapPin, CreditCard, Truck, CheckCircle2, ShoppingBag } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { useCart } from '../context/CartContext';
import Header from '../components/Header';
import { socket } from '../socket';

export default function Orders() {
  const { orders, cartCount, cartTotal } = useCart();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#f0f2f2] pb-20">
      <Header 
        cartCount={cartCount} 
        cartTotal={cartTotal} 
        onCheckout={() => {}} 
      />

      <main className="max-w-4xl mx-auto p-4">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-200 rounded-full transition-colors"
          >
            <ChevronLeft size={24} />
          </button>
          <h1 className="text-2xl font-bold">Your Orders</h1>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white p-12 rounded-lg shadow-sm text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Package size={40} className="text-gray-400" />
            </div>
            <h2 className="text-xl font-bold mb-2">No orders found</h2>
            <p className="text-gray-600 mb-6">Looks like you haven't placed any orders yet.</p>
            <button 
              onClick={() => navigate('/')}
              className="bg-[#ffd814] hover:bg-[#f7ca00] text-black px-8 py-3 rounded-lg font-medium shadow-sm transition-colors"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
                {/* Order Header */}
                <div className="bg-gray-50 p-4 border-b border-gray-200 flex flex-wrap gap-4 justify-between items-center text-sm">
                  <div className="flex gap-8">
                    <div>
                      <p className="text-gray-500 uppercase text-[10px] font-bold">Order Placed</p>
                      <p className="font-medium">{new Date(order.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 uppercase text-[10px] font-bold">Total</p>
                      <p className="font-medium">₹{(order.total || 0).toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 uppercase text-[10px] font-bold">Ship To</p>
                      <div className="group relative cursor-pointer">
                        <p className="text-blue-600 hover:text-[#C7511F] font-medium flex items-center gap-1">
                          {order.address.fullName}
                          <ChevronRight size={14} className="rotate-90" />
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-500 uppercase text-[10px] font-bold">Order # {order.id}</p>
                    <div className="flex gap-2 mt-1">
                      <button className="text-blue-600 hover:text-[#C7511F] hover:underline">Order Details</button>
                      <span className="text-gray-300">|</span>
                      <button className="text-blue-600 hover:text-[#C7511F] hover:underline">Invoice</button>
                    </div>
                  </div>
                </div>

                {/* Order Content */}
                <div className="p-4">
                  <div className="mb-10">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex flex-col">
                        <h3 className={`font-bold text-xl flex items-center gap-2 ${
                          order.status === 'Delivered' ? 'text-green-600' : 'text-[#f08804]'
                        }`}>
                          {order.status === 'Delivered' ? <CheckCircle2 size={24} /> : <Package size={24} />}
                          {order.status}
                        </h3>
                        <p className="text-xs text-gray-500 mt-1">
                          {order.status === 'Delivered' ? 'Your package was delivered' : 'Your package is on its way'}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Estimated Delivery</p>
                        <p className="text-sm font-bold text-gray-800">
                          {new Date(new Date(order.date).getTime() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                        </p>
                      </div>
                    </div>
                    
                    {/* Enhanced Stepper Look */}
                    <div className="relative px-2 py-4">
                      {/* Progress Line Background */}
                      <div className="absolute top-[38px] left-10 right-10 h-1 bg-gray-200 rounded-full"></div>
                      
                      {/* Active Progress Line */}
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ 
                          width: order.status === 'Ordered' ? '0%' : 
                                 order.status === 'Shipping' ? '33.33%' : 
                                 order.status === 'Out for Delivery' ? '66.66%' : 
                                 order.status === 'Delivered' ? 'calc(100% - 80px)' : '0%' 
                        }}
                        className="absolute top-[38px] left-10 h-1 bg-green-500 rounded-full z-10 transition-all duration-1000"
                      ></motion.div>

                      <div className="relative flex justify-between">
                        {[
                          { label: 'Ordered', icon: ShoppingBag },
                          { label: 'Shipping', icon: Package },
                          { label: 'Out for Delivery', icon: Truck },
                          { label: 'Delivered', icon: CheckCircle2 }
                        ].map((step, index) => {
                          const statuses = ['Ordered', 'Shipping', 'Out for Delivery', 'Delivered'];
                          const currentIdx = statuses.indexOf(order.status);
                          const isCompleted = index <= currentIdx;
                          const isActive = index === currentIdx;
                          const Icon = step.icon;

                          return (
                            <div key={step.label} className="flex flex-col items-center z-20">
                              <motion.div 
                                initial={false}
                                animate={{ 
                                  scale: isActive ? 1.2 : 1,
                                  backgroundColor: isCompleted ? '#22c55e' : '#ffffff',
                                  borderColor: isCompleted ? '#22c55e' : '#d1d5db',
                                  color: isCompleted ? '#ffffff' : '#9ca3af'
                                }}
                                className={`w-12 h-12 rounded-full flex items-center justify-center border-2 shadow-sm transition-colors duration-500 ${
                                  isActive ? 'ring-4 ring-green-100' : ''
                                }`}
                              >
                                <Icon size={22} />
                              </motion.div>
                              <span className={`mt-3 text-[10px] font-bold uppercase tracking-tight text-center w-16 leading-tight ${
                                isCompleted ? 'text-green-600' : 'text-gray-400'
                              }`}>
                                {step.label}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex gap-4">
                        <div className="w-20 h-20 bg-gray-50 rounded p-1 flex items-center justify-center shrink-0">
                          <img src={item.image} alt={item.title} className="max-h-full max-w-full object-contain" />
                        </div>
                        <div className="flex-1">
                          <h4 className="text-blue-600 hover:text-[#C7511F] hover:underline font-medium text-sm line-clamp-2 mb-1 cursor-pointer">
                            {item.title}
                          </h4>
                          <p className="text-xs text-gray-500 mb-2">Quantity: {item.quantity}</p>
                          <div className="flex gap-2">
                            <button className="bg-[#ffd814] hover:bg-[#f7ca00] text-xs font-medium py-1.5 px-4 rounded-full shadow-sm border border-[#FCD200]">
                              Buy it again
                            </button>
                            <button 
                              onClick={() => navigate('/reselling-wallet')}
                              className="bg-white hover:bg-gray-50 text-xs font-medium py-1.5 px-4 rounded-full shadow-sm border border-gray-300 text-blue-600"
                            >
                              Resell
                            </button>
                            <button className="bg-white hover:bg-gray-50 text-xs font-medium py-1.5 px-4 rounded-full shadow-sm border border-gray-300">
                              View your item
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 pt-4 border-t border-gray-100 flex flex-wrap gap-6 text-sm">
                    <div className="flex items-start gap-2 max-w-xs">
                      <MapPin size={18} className="text-gray-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-gray-700 mb-0.5">Delivery Address</p>
                        <p className="text-gray-600 text-xs leading-relaxed">
                          {order.address.fullName}<br />
                          {order.address.houseNo}, {order.address.area}<br />
                          {order.address.city}, {order.address.state} - {order.address.pincode}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CreditCard size={18} className="text-gray-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-bold text-gray-700 mb-0.5">Payment Method</p>
                        <p className="text-gray-600 text-xs">{order.paymentMethod.replace(/_/g, ' ').toUpperCase()}</p>
                        {order.paymentDetails?.utr && (
                          <p className="text-[10px] font-mono text-blue-600 mt-1">UTR: {order.paymentDetails.utr}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Order Footer */}
                <div className="bg-gray-50 p-3 border-t border-gray-200 flex justify-end gap-4">
                  <button className="text-xs font-medium text-gray-700 hover:underline">Archive order</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
