import React from 'react';
import Header from '../components/Header';
import { useCart } from '../context/CartContext';

export default function PlaceholderPage({ title }: { title: string }) {
  const { cartCount, cartTotal } = useCart();
  
  return (
    <div className="min-h-screen bg-white font-sans pb-20">
      <Header 
        cartCount={cartCount} 
        cartTotal={cartTotal} 
        onCheckout={() => {}} 
      />
      <div className="flex flex-col items-center justify-center h-[60vh] px-4 text-center">
        <h1 className="text-2xl font-bold mb-2">{title}</h1>
        <p className="text-gray-600">This page is coming soon!</p>
      </div>
    </div>
  );
}
