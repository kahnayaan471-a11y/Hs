import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Heart, ShoppingCart } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { toast } from 'sonner';

export default function Wishlist() {
  const { wishlistItems, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();

  const handleAddToCart = (product: any) => {
    addToCart(product);
    toast.success('Added to cart!');
  };

  return (
    <div className="min-h-screen bg-[#eaeded] font-sans pb-20 md:pb-0">
      <div className="bg-white p-4 shadow-sm flex items-center gap-4 sticky top-0 z-10">
        <Link to="/" className="text-gray-600 hover:text-black">
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-xl font-bold">Your Wishlist</h1>
      </div>

      <div className="max-w-4xl mx-auto p-4">
        {wishlistItems.length === 0 ? (
          <div className="bg-white p-8 rounded-lg shadow-sm text-center mt-4">
            <Heart size={48} className="mx-auto text-gray-300 mb-4" />
            <h2 className="text-xl font-bold mb-2">Your Wishlist is empty</h2>
            <p className="text-gray-600 mb-6">Save items you want to buy later.</p>
            <Link 
              to="/" 
              className="bg-[#ffd814] hover:bg-[#f7ca00] px-6 py-2 rounded-full font-medium transition-colors inline-block"
            >
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm mt-4 divide-y divide-gray-200">
            <div className="p-4 bg-gray-50 border-b border-gray-200 rounded-t-lg">
              <h2 className="font-bold text-lg">Saved Items ({wishlistItems.length})</h2>
            </div>
            
            {wishlistItems.map((item) => (
              <div key={item.id} className="p-4 flex flex-col sm:flex-row gap-4">
                <Link to={`/product/${item.id}`} className="w-full sm:w-32 h-32 shrink-0 bg-gray-50 rounded-md flex items-center justify-center p-2">
                  <img src={item.image} alt={item.title} className="max-w-full max-h-full object-contain mix-blend-multiply" referrerPolicy="no-referrer" />
                </Link>
                
                <div className="flex-1 flex flex-col">
                  <Link to={`/product/${item.id}`} className="font-medium text-gray-900 hover:text-orange-600 line-clamp-2 mb-1">
                    {item.title}
                  </Link>
                  
                  <div className="flex items-start mb-2">
                    <span className="text-sm mt-1">₹</span>
                    <span className="text-xl font-bold">{Math.floor(item.price)}</span>
                    <span className="text-sm mt-1">{((item.price || 0) % 1).toFixed(2).substring(1)}</span>
                  </div>
                  
                  <div className="text-sm text-[#007600] mb-3">In Stock</div>
                  
                  <div className="mt-auto flex flex-wrap gap-2">
                    <button 
                      onClick={() => handleAddToCart(item)}
                      className="bg-[#ffd814] hover:bg-[#f7ca00] px-4 py-1.5 rounded-full text-sm font-medium transition-colors flex items-center gap-2"
                    >
                      <ShoppingCart size={16} />
                      Add to Cart
                    </button>
                    <button 
                      onClick={() => removeFromWishlist(item.id)}
                      className="bg-white border border-gray-300 hover:bg-gray-50 px-4 py-1.5 rounded-full text-sm font-medium transition-colors"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
