import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, Trash2, Plus, Minus, ArrowRight, ChevronLeft } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import Header from '../components/Header';
import AddressModal from '../components/AddressModal';
import PaymentModal from '../components/PaymentModal';
import AuthModal from '../components/AuthModal';
import { socket } from '../socket';
import { toast } from 'sonner';
import { useTheme } from '../hooks/useTheme';

export default function Cart() {
  const { cartItems, removeFromCart, updateQuantity, cartTotal, cartCount, placeOrder, promoDiscount, applyPromoCode } = useCart();
  const { isLoggedIn } = useAuth();
  const navigate = useNavigate();
  const { brandName } = useTheme();
  
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState<any>(() => {
    const savedAddress = localStorage.getItem('deliveryAddress');
    return savedAddress ? JSON.parse(savedAddress) : null;
  });
  const [promoCodeInput, setPromoCodeInput] = useState('');

  const handleApplyPromoCode = async () => {
    const q = query(collection(db, 'promoCodes'), where('code', '==', promoCodeInput.toUpperCase()), where('active', '==', true));
    const snapshot = await getDocs(q);
    if (!snapshot.empty) {
      const promoData = snapshot.docs[0].data();
      applyPromoCode(promoData.discount, promoData.type, promoCodeInput.toUpperCase());
      toast.success('Promo code applied!');
    } else {
      toast.error('Invalid promo code');
    }
  };

  const handleCheckout = () => {
    if (cartCount === 0) return toast.error('Cart is empty');
    if (!isLoggedIn) {
      setIsAuthModalOpen(true);
      return;
    }
    if (deliveryAddress) {
      setIsPaymentModalOpen(true);
    } else {
      setIsAddressModalOpen(true);
    }
  };

  const handleAddressConfirm = (address: any) => {
    setDeliveryAddress(address);
    localStorage.setItem('deliveryAddress', JSON.stringify(address));
    setIsAddressModalOpen(false);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentConfirm = (method: string, details?: { utr?: string; isReselling?: boolean; profitMargin?: number; resellerEmail?: string; resellerPassword?: string; realPrice?: number }) => {
    // Clean data to avoid circular structure errors
    const cleanAddress = deliveryAddress ? {
      fullName: String(deliveryAddress.fullName || ''),
      phone: String(deliveryAddress.phone || ''),
      houseNo: String(deliveryAddress.houseNo || ''),
      area: String(deliveryAddress.area || ''),
      landmark: String(deliveryAddress.landmark || ''),
      pincode: String(deliveryAddress.pincode || ''),
      city: String(deliveryAddress.city || ''),
      state: String(deliveryAddress.state || ''),
      type: (deliveryAddress.type === 'work' ? 'work' : 'home') as 'home' | 'work'
    } : null;

    // Clean data to avoid circular structure errors and break any potential proxies
    const cleanDetails = details ? JSON.parse(JSON.stringify({
      utr: details.utr,
      isReselling: details.isReselling,
      profitMargin: details.profitMargin,
      resellerEmail: details.resellerEmail,
      resellerPassword: details.resellerPassword,
      realPrice: details.realPrice
    })) : {};

    socket.emit('place_order', {
      total: Number(cartTotal + (cleanDetails.profitMargin || 0)),
      address: cleanAddress,
      paymentMethod: method,
      ...cleanDetails
    });
    
    if (cleanAddress) {
      placeOrder(cleanAddress, method, cleanDetails);
    }
    
    setIsPaymentModalOpen(false);
    toast.success(`Order placed successfully! Delivering to ${cleanAddress?.fullName || 'your address'}`);
    navigate('/orders');
  };

  return (
    <div className="min-h-screen bg-[#f0f2f2] pb-20">
      <Header 
        cartCount={cartCount} 
        cartTotal={cartTotal} 
        onCheckout={handleCheckout} 
      />

      <AddressModal 
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        onConfirm={handleAddressConfirm}
      />

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onConfirm={handlePaymentConfirm}
        onEditAddress={() => {
          setIsPaymentModalOpen(false);
          setIsAddressModalOpen(true);
        }}
        totalAmount={cartTotal}
        deliveryAddress={deliveryAddress}
      />

      <main className="max-w-4xl mx-auto p-4">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-1 text-sm text-blue-600 mb-4 hover:underline"
        >
          <ChevronLeft size={16} />
          Back
        </button>

        <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
          <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <ShoppingCart size={28} />
            Shopping Cart
          </h1>

          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-500 space-y-4">
              <ShoppingCart size={80} strokeWidth={1} className="text-gray-300" />
              <p className="text-xl font-medium">Your {brandName} Cart is empty</p>
            </div>
          ) : (
            <div className="space-y-6">
              {cartItems.map((item) => (
                <div key={item.id} className="flex flex-col sm:flex-row gap-6 pb-6 border-b last:border-0">
                  <div className="w-full sm:w-40 h-40 bg-gray-50 rounded-lg flex items-center justify-center p-2 shrink-0">
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <h3 className="text-lg font-medium leading-tight">{item.title}</h3>
                    <p className="text-sm text-green-700 font-medium">In Stock</p>
                    <p className="text-xs text-gray-500">Eligible for FREE Shipping</p>
                    
                    <div className="flex items-center gap-4 mt-4">
                      <div className="flex items-center border rounded-lg bg-gray-50 shadow-sm">
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-2 hover:bg-gray-200 rounded-l-lg transition-colors"
                        >
                          <Minus size={18} />
                        </button>
                        <span className="px-4 py-1 font-bold text-lg min-w-[40px] text-center">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-2 hover:bg-gray-200 rounded-r-lg transition-colors"
                        >
                          <Plus size={18} />
                        </button>
                      </div>
                      
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="text-sm text-blue-600 hover:underline flex items-center gap-1"
                      >
                        <Trash2 size={16} />
                        Delete
                      </button>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="text-xl font-bold text-[#B12704]">₹{((item.price || 0) * item.quantity).toFixed(2)}</p>
                    <p className="text-xs text-gray-500">₹{(item.price || 0).toFixed(2)} each</p>
                  </div>
                </div>
              ))}

              <div className="flex flex-col items-end pt-6 border-t space-y-4">
                <div className="flex flex-col gap-2 w-full sm:w-auto">
                  <label className="text-sm font-medium text-gray-700">Gift Card or Promo Code</label>
                  <div className="flex gap-4">
                    <input 
                      type="text" 
                      value={promoCodeInput} 
                      onChange={e => setPromoCodeInput(e.target.value)} 
                      placeholder="Enter code"
                      className="border rounded-lg px-4 py-2 w-full sm:w-48"
                    />
                    <button 
                      onClick={handleApplyPromoCode}
                      className="bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded-lg font-medium transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                </div>
                {promoDiscount > 0 && (
                  <div className="text-right text-green-600 font-medium">
                    Discount: -₹{promoDiscount.toFixed(2)}
                  </div>
                )}
                <div className="text-right">
                  <span className="text-lg text-gray-700">Subtotal ({cartCount} items): </span>
                  <span className="text-2xl font-bold text-[#B12704]">₹{cartTotal.toFixed(2)}</span>
                </div>
                
                <button 
                  onClick={handleCheckout}
                  className="w-full sm:w-auto bg-[#ffd814] hover:bg-[#f7ca00] text-black px-12 py-3 rounded-lg font-bold shadow-md transition-colors flex items-center justify-center gap-2"
                >
                  Proceed to Buy
                  <ArrowRight size={20} />
                </button>
              </div>
            </div>
          )}
        </div>

        {cartItems.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="font-bold text-lg mb-4">Your items</h2>
            <p className="text-sm text-gray-600">
              The price and availability of items at {brandName} are subject to change. The shopping cart is a temporary place to store a list of your items and reflects each item's most recent price.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
