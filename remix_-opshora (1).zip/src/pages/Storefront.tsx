import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import PaymentModal from '../components/PaymentModal';
import AddressModal from '../components/AddressModal';
import { useCart } from '../context/CartContext';
import { socket } from '../socket';
import { Product } from '../types';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import SplashScreen from '../components/SplashScreen';
import { handleFirestoreError, OperationType } from '../utils/firestoreError';

export default function Storefront() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { addToCart, cartCount, cartTotal, placeOrder } = useCart();
  const [products, setProducts] = useState<Product[]>([]);
  const [sliders, setSliders] = useState<any[]>([]);
  const [currentSliderIndex, setCurrentSliderIndex] = useState(0);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState<any>(null);
  const [adCode, setAdCode] = useState('');
  const [showSplash, setShowSplash] = useState(() => {
    return !localStorage.getItem('splashShown');
  });

  const handleSplashComplete = () => {
    localStorage.setItem('splashShown', 'true');
    setShowSplash(false);
  };

  useEffect(() => {
    const unsubscribeAd = onSnapshot(doc(db, 'settings', 'adConfig'), (doc) => {
      if (doc.exists()) {
        setAdCode(doc.data().code || '');
      }
    }, (error) => handleFirestoreError(error, OperationType.GET, 'settings/adConfig'));
    return () => unsubscribeAd();
  }, []);

  useEffect(() => {
    socket.on('initial_data', (data) => {
      setProducts(data.products);
      setSliders(data.sliders || []);
    });
    socket.on('products_update', (updatedProducts) => {
      setProducts(updatedProducts);
    });
    socket.on('sliders_update', (updatedSliders) => {
      setSliders(updatedSliders);
    });

    if (socket.connected) {
      socket.disconnect();
      socket.connect();
    }

    return () => {
      socket.off('initial_data');
      socket.off('products_update');
      socket.off('sliders_update');
    };
  }, []);

  useEffect(() => {
    if (sliders.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSliderIndex((prev) => (prev + 1) % sliders.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [sliders]);

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    toast.success('Added to cart!');
  };

  const handleCheckout = () => {
    if (cartCount === 0) return toast.error('Cart is empty');
    setIsAddressModalOpen(true);
  };

  const handleAddressConfirm = (address: any) => {
    setDeliveryAddress(address);
    setIsAddressModalOpen(false);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentConfirm = (method: string) => {
    socket.emit('place_order', {
      total: cartTotal,
      address: deliveryAddress,
      paymentMethod: method
    });
    
    placeOrder(deliveryAddress, method);
    
    setIsPaymentModalOpen(false);
    toast.success(`Order placed successfully! Delivering to ${deliveryAddress.fullName}`);
    navigate('/orders');
  };

  const filteredProducts = products;

  return (
    <div className="min-h-screen bg-[#eaeded] font-sans">
      {showSplash && <SplashScreen onComplete={handleSplashComplete} />}
      <Header 
        cartCount={cartCount} 
        cartTotal={cartTotal} 
        onCheckout={handleCheckout} 
      />

      <AddressModal 
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        onConfirm={handleAddressConfirm}
      />

      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onConfirm={handlePaymentConfirm}
        totalAmount={cartTotal}
        deliveryAddress={deliveryAddress}
      />
      
      <main className="max-w-[1500px] mx-auto relative">
        {/* Hero Banner Slider */}
        <div className="relative overflow-hidden">
          <div className="h-[250px] md:h-[350px] lg:h-[450px] w-full bg-gradient-to-b from-blue-400 to-[#eaeded] mask-image-b-gradient relative">
            {sliders.length > 0 ? (
              sliders.map((slider, index) => (
                <a 
                  key={slider.id} 
                  href={slider.link || '#'} 
                  className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSliderIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
                >
                  <img 
                    src={slider.image} 
                    alt={`Hero Slider ${index + 1}`} 
                    className="w-full h-full object-cover mask-image-b-gradient"
                    referrerPolicy="no-referrer"
                  />
                </a>
              ))
            ) : (
              <img 
                src="https://picsum.photos/seed/amazonhero/1500/600" 
                alt="Hero" 
                className="w-full h-full object-cover mask-image-b-gradient"
                referrerPolicy="no-referrer"
              />
            )}
            
            {/* Slider Controls */}
            {sliders.length > 1 && (
              <div className="absolute bottom-36 left-0 right-0 flex justify-center gap-2 z-20">
                {sliders.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSliderIndex(index)}
                    className={`w-2 h-2 rounded-full transition-colors ${index === currentSliderIndex ? 'bg-white' : 'bg-white/50'}`}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="absolute bottom-0 w-full h-32 bg-gradient-to-t from-[#eaeded] to-transparent z-10"></div>
        </div>

        {/* Product Grid */}
        <div className="px-4 md:px-6 -mt-32 md:-mt-64 relative z-20 pb-10">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
            
            {filteredProducts.slice(0, 2).map(product => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={() => handleAddToCart(product)} 
              />
            ))}

            {/* Full width banner ad */}
            {adCode && (
              <div className="col-span-2 sm:col-span-3 md:col-span-4 lg:col-span-5 bg-white p-2 my-2">
                <div className="border border-gray-200 flex items-center justify-center bg-gray-50 relative overflow-hidden" dangerouslySetInnerHTML={{ __html: adCode }} />
              </div>
            )}

            {filteredProducts.slice(2).map(product => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={() => handleAddToCart(product)} 
              />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
