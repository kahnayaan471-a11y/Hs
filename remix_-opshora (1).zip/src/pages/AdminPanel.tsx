import React, { useState, useEffect } from 'react';
import { socket } from '../socket';
import { Link } from 'react-router-dom';
import { Users, ShoppingBag, DollarSign, Plus, Trash2, ArrowLeft, Mail, LayoutGrid, Image as ImageIcon, Tag, Sun, Moon, CheckCircle, XCircle, ArrowUpRight, Clock } from 'lucide-react';
import { collection, onSnapshot, query, orderBy, updateDoc, doc, deleteDoc, addDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner';
import { Order, Category } from '../types';
import { handleFirestoreError, OperationType } from '../utils/firestoreError';
import { useThemeContext } from '../context/ThemeContext';

export default function AdminPanel() {
  const { user: currentUser, isAuthReady, createAccountManager } = useAuth();
  const { isDarkMode, toggleDarkMode } = useThemeContext();
  console.log('AdminPanel rendered, currentUser:', currentUser, 'isAuthReady:', isAuthReady);
  
  const [stats, setStats] = useState({ activeUsers: 0, totalOrders: 0, totalRevenue: 0 });
  const [products, setProducts] = useState<any[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<any[]>([]);
  const [promoCodes, setPromoCodes] = useState<any[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [sliders, setSliders] = useState<any[]>([]);
  const [resellers, setResellers] = useState<{email: string, password: string, isBanned: boolean}[]>([]);
  const [resellerEarnings, setResellerEarnings] = useState<{ id: string, email: string, amount: number, description: string, date: string, status: 'pending' | 'completed' }[]>([]);
  const [resellerWithdrawals, setResellerWithdrawals] = useState<{ id: string, email: string, amount: number, upiId: string, date: string, status: 'pending' | 'completed' | 'rejected' }[]>([]);
  
  // Reseller Earning State
  const [earningAmount, setEarningAmount] = useState('');
  const [earningDescription, setEarningDescription] = useState('');
  const [selectedResellerEmail, setSelectedResellerEmail] = useState('');
  
  // Promo code form state
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState('');
  const [discountType, setDiscountType] = useState('percentage');
  
  // Reseller Password form state
  const [newResellerEmail, setNewResellerEmail] = useState('');
  const [newResellerPassword, setNewResellerPassword] = useState('');
  
  // Form state
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [originalPrice, setOriginalPrice] = useState('');
  const [rating, setRating] = useState('4.5');
  const [reviews, setReviews] = useState('100');
  const [image1, setImage1] = useState('');
  const [image2, setImage2] = useState('');
  const [image3, setImage3] = useState('');
  const [image4, setImage4] = useState('');
  const [image5, setImage5] = useState('');
  const [prime, setPrime] = useState(false);
  const [selectedCategoryId, setSelectedCategoryId] = useState('');

  // Category form state
  const [catName, setCatName] = useState('');
  const [catImage, setCatImage] = useState('');

  // Slider form state
  const [sliderImage, setSliderImage] = useState('');
  const [sliderLink, setSliderLink] = useState('');
  
  // Review form state
  const [reviewModalProductId, setReviewModalProductId] = useState<number | null>(null);
  const [reviewUserName, setReviewUserName] = useState('');
  const [reviewUserPhoto, setReviewUserPhoto] = useState('');
  const [reviewRating, setReviewRating] = useState('5');
  const [reviewComment, setReviewComment] = useState('');
  const [allReviews, setAllReviews] = useState<any[]>([]);
  const [showReviewsList, setShowReviewsList] = useState(false);
  
  // Ad code state
  const [adCode, setAdCode] = useState('');
  
  // Admin Password state
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [inputPassword, setInputPassword] = useState('');
  const [storedPassword, setStoredPassword] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [activeAdminTab, setActiveAdminTab] = useState<'dashboard' | 'products' | 'customers' | 'reselling' | 'settings'>('dashboard');
  
  // Brand name state
  const [brandName, setBrandName] = useState('Opshora');
  const [primaryColor, setPrimaryColor] = useState('#2563eb');
  const [secondaryColor, setSecondaryColor] = useState('#1e40af');
  
  // UPI Edit state
  const [editingUpiId, setEditingUpiId] = useState<string | null>(null);
  const [tempUpiId, setTempUpiId] = useState('');
  
  const handleUpdateBrandConfig = async () => {
    try {
      await setDoc(doc(db, 'settings', 'brandConfig'), { 
        name: brandName,
        primaryColor,
        secondaryColor
      }, { merge: true });
      toast.success('Brand configuration updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'settings/brandConfig');
      toast.error('Failed to update brand configuration');
    }
  };

  // Staff form state


  useEffect(() => {
    // Fetch brand name
    const unsubscribeBrand = onSnapshot(doc(db, 'settings', 'brandConfig'), (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        setBrandName(data.name || 'Opshora');
        setPrimaryColor(data.primaryColor || '#2563eb');
        setSecondaryColor(data.secondaryColor || '#1e40af');
      }
    });

    // Socket listeners
    socket.on('initial_data', (data) => {
      setProducts(data.products);
      setStats(data.stats);
      setCategories(data.categories || []);
      setSliders(data.sliders || []);
      setResellers(data.resellers || []);
      setResellerEarnings(data.resellerEarnings || []);
      setResellerWithdrawals(data.resellerWithdrawals || []);
    });
    socket.on('stats_update', (newStats) => setStats(newStats));
    socket.on('products_update', (newProducts) => setProducts(newProducts));
    socket.on('categories_update', (newCategories) => setCategories(newCategories));
    socket.on('sliders_update', (newSliders) => setSliders(newSliders));
    socket.on('resellers_update', (newResellers) => setResellers(newResellers));
    socket.on('reseller_earnings_update', (newEarnings) => setResellerEarnings(newEarnings));
    socket.on('reseller_withdrawals_update', (newWithdrawals) => setResellerWithdrawals(newWithdrawals));

    // Firestore listeners for registered users
    let unsubscribeUsers = () => {};
    if (currentUser?.role === 'admin' && auth.currentUser) {
      const usersQuery = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
      unsubscribeUsers = onSnapshot(usersQuery, (snapshot) => {
        const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setRegisteredUsers(users);
      }, (error) => handleFirestoreError(error, OperationType.GET, 'users'));
    }

    // Firestore listeners for promo codes
    let unsubscribePromoCodes = () => {};
    if (currentUser?.role === 'admin' && auth.currentUser) {
      const promoCodesQuery = query(collection(db, 'promoCodes'), orderBy('code', 'asc'));
      unsubscribePromoCodes = onSnapshot(promoCodesQuery, (snapshot) => {
        const codes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setPromoCodes(codes);
      }, (error) => handleFirestoreError(error, OperationType.GET, 'promoCodes'));
    }

    // Firestore listeners for all orders
    let unsubscribeOrders = () => {};
    if (currentUser?.role === 'admin' && auth.currentUser) {
      const ordersQuery = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
      unsubscribeOrders = onSnapshot(ordersQuery, (snapshot) => {
        const allOrders = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          date: doc.data().createdAt?.toDate()?.toISOString() || new Date().toISOString()
        })) as Order[];
        setOrders(allOrders);
      }, (error) => handleFirestoreError(error, OperationType.GET, 'orders'));
    }

    // Firestore listener for ad code
    let unsubscribeAd = () => {};
    if (currentUser?.role === 'admin' && auth.currentUser) {
      unsubscribeAd = onSnapshot(doc(db, 'settings', 'adConfig'), (doc) => {
        if (doc.exists()) {
          setAdCode(doc.data().code || '');
        }
      }, (error) => handleFirestoreError(error, OperationType.GET, 'settings/adConfig'));
    }

    // Firestore listener for admin password
    let unsubscribeAdminConfig = () => {};
    if (auth.currentUser) {
      unsubscribeAdminConfig = onSnapshot(doc(db, 'settings', 'adminConfig'), (doc) => {
        if (doc.exists()) {
          setStoredPassword(doc.data().password || 'admin123');
        } else {
          setStoredPassword('admin123');
        }
      }, (error) => handleFirestoreError(error, OperationType.GET, 'settings/adminConfig'));
    }

    // Firestore listeners for all reviews
    let unsubscribeReviews = () => {};
    if (currentUser?.role === 'admin' && auth.currentUser) {
      const reviewsQuery = query(collection(db, 'reviews'), orderBy('createdAt', 'desc'));
      unsubscribeReviews = onSnapshot(reviewsQuery, (snapshot) => {
        const reviews = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setAllReviews(reviews);
      }, (error) => handleFirestoreError(error, OperationType.GET, 'reviews'));
    }

    if (socket.connected) {
      socket.disconnect();
      socket.connect();
    }

    return () => {
      socket.off('initial_data');
      socket.off('stats_update');
      socket.off('products_update');
      socket.off('categories_update');
      socket.off('sliders_update');
      socket.off('resellers_update');
      unsubscribeUsers();
      unsubscribePromoCodes();
      unsubscribeOrders();
      unsubscribeAd();
      unsubscribeAdminConfig();
      unsubscribeBrand();
      unsubscribeReviews();
    };
  }, [currentUser]);

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputPassword === storedPassword) {
      setIsUnlocked(true);
      toast.success('Admin Panel Unlocked');
    } else {
      toast.error('Incorrect Password');
    }
  };

  const handleUpdateAdminPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminPassword) return;
    try {
      await setDoc(doc(db, 'settings', 'adminConfig'), { password: newAdminPassword }, { merge: true });
      setNewAdminPassword('');
      toast.success('Admin password updated successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/adminConfig');
      toast.error('Failed to update admin password');
    }
  };

  const handleUpdateAdCode = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'settings', 'adConfig'), { code: adCode }, { merge: true });
      toast.success('Ad code updated successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/adConfig');
      toast.error('Failed to update ad code');
    }
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !price || !image1) return;
    
    const images = [image1, image2, image3, image4, image5].filter(img => img.trim() !== '');

    const productData = {
      title,
      price: parseFloat(price),
      originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
      image: image1,
      images: images,
      prime,
      rating: parseFloat(rating),
      reviews: parseInt(reviews),
      categoryId: selectedCategoryId
    };

    if (editingProductId) {
      socket.emit('edit_product', { ...productData, id: editingProductId });
      toast.success('Product updated successfully');
    } else {
      socket.emit('add_product', productData);
      toast.success('Product added successfully');
    }
    
    setEditingProductId(null);
    setTitle('');
    setPrice('');
    setOriginalPrice('');
    setRating('4.5');
    setReviews('100');
    setImage1('');
    setImage2('');
    setImage3('');
    setImage4('');
    setImage5('');
    setPrime(false);
    setSelectedCategoryId('');
  };

  const handleEditProduct = (product: any) => {
    setEditingProductId(product.id);
    setTitle(product.title);
    setPrice(product.price.toString());
    setOriginalPrice(product.originalPrice ? product.originalPrice.toString() : '');
    setRating(product.rating.toString());
    setReviews(product.reviews.toString());
    setImage1(product.image);
    setImage2(product.images?.[1] || '');
    setImage3(product.images?.[2] || '');
    setImage4(product.images?.[3] || '');
    setImage5(product.images?.[4] || '');
    setPrime(product.prime);
    setSelectedCategoryId(product.categoryId || '');
    
    // Scroll to form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelEdit = () => {
    setEditingProductId(null);
    setTitle('');
    setPrice('');
    setOriginalPrice('');
    setRating('4.5');
    setReviews('100');
    setImage1('');
    setImage2('');
    setImage3('');
    setImage4('');
    setImage5('');
    setPrime(false);
    setSelectedCategoryId('');
  };

  const handleDelete = (id: number) => {
    socket.emit('delete_product', id);
    toast.success('Product deleted successfully');
  };

  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalProductId || !reviewUserName || !reviewComment) return;
    
    try {
      await addDoc(collection(db, 'reviews'), {
        productId: Number(reviewModalProductId),
        userName: reviewUserName,
        userPhoto: reviewUserPhoto || `https://ui-avatars.com/api/?name=${encodeURIComponent(reviewUserName)}&background=random`,
        rating: parseFloat(reviewRating),
        text: reviewComment, // We'll use 'text' to match existing user reviews
        createdAt: serverTimestamp(),
        isAdminReview: true // Flag to distinguish
      });
      
      toast.success('Review added successfully');
      setReviewModalProductId(null);
      setReviewUserName('');
      setReviewUserPhoto('');
      setReviewRating('5');
      setReviewComment('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'reviews');
      toast.error('Failed to add review');
    }
  };

  const handleDeleteReview = async (id: string) => {
    console.log('Attempting to delete review:', id);
    try {
      await deleteDoc(doc(db, 'reviews', id));
      console.log('Review deleted successfully:', id);
      toast.success('Review deleted successfully');
    } catch (error) {
      console.error('Error deleting review:', error);
      handleFirestoreError(error, OperationType.DELETE, `reviews/${id}`);
      toast.error('Failed to delete review');
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName || !catImage) return;
    socket.emit('add_category', { name: catName, image: catImage });
    setCatName('');
    setCatImage('');
    toast.success('Category added successfully');
  };

  const handleDeleteCategory = (id: string) => {
    socket.emit('delete_category', id);
    toast.success('Category deleted');
  };

  const handleAddSlider = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sliderImage) return;
    socket.emit('add_slider', { image: sliderImage, link: sliderLink || '#' });
    setSliderImage('');
    setSliderLink('');
    toast.success('Slider added successfully');
  };

  const handleDeleteSlider = (id: string) => {
    socket.emit('delete_slider', id);
    toast.success('Slider deleted');
  };

  const handleToggleBan = async (userId: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'users', userId), { isBanned: !currentStatus });
      toast.success(`User ${!currentStatus ? 'banned' : 'unbanned'} successfully`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
      toast.error('Failed to update user status');
    }
  };

  const handleUpdateStatus = async (orderId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
      toast.success(`Order status updated to ${newStatus}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
      toast.error('Failed to update status');
    }
  };

  const handleAddPromoCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCode || !discount) return;
    try {
      await addDoc(collection(db, 'promoCodes'), {
        code: promoCode.toUpperCase(),
        discount: parseFloat(discount),
        type: discountType,
        active: true
      });
      setPromoCode('');
      setDiscount('');
      toast.success('Promo code added successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'promoCodes');
      toast.error('Failed to add promo code');
    }
  };

  const handleDeletePromoCode = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'promoCodes', id));
      toast.success('Promo code deleted');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `promoCodes/${id}`);
      toast.error('Failed to delete promo code');
    }
  };

  const handleAddReseller = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newResellerEmail.trim() || !newResellerPassword.trim()) return;
    socket.emit('add_reseller', { 
      email: newResellerEmail.trim(), 
      password: newResellerPassword.trim() 
    });
    setNewResellerEmail('');
    setNewResellerPassword('');
    toast.success('Reseller added!');
  };

  const handleDeleteReseller = (email: string) => {
    socket.emit('delete_reseller', email);
    toast.success('Reseller deleted!');
  };

  const handleToggleBanReseller = (email: string) => {
    socket.emit('toggle_ban_reseller', email);
    toast.success('Reseller status updated!');
  };

  const handleAddEarning = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedResellerEmail || !earningAmount || !earningDescription) {
      toast.error('Please fill all fields');
      return;
    }
    socket.emit("add_reseller_earning", {
      email: selectedResellerEmail,
      amount: parseFloat(earningAmount),
      description: earningDescription
    });
    setEarningAmount('');
    setEarningDescription('');
    toast.success('Earning added successfully');
  };

  const handleUpdateEarningStatus = (id: string, status: 'pending' | 'completed') => {
    socket.emit("update_reseller_earning_status", { id, status });
    toast.success(`Earning status updated to ${status}`);
  };

  const handleDeleteEarning = (id: string) => {
    socket.emit("delete_reseller_earning", id);
    toast.success('Earning deleted');
  };

  const handleUpdateWithdrawalStatus = (id: string, status: 'pending' | 'completed' | 'rejected') => {
    socket.emit("update_withdrawal_status", { id, status });
    toast.success(`Withdrawal status updated to ${status}`);
  };

  const handleDeleteWithdrawal = (id: string) => {
    socket.emit("delete_withdrawal", id);
    toast.success('Withdrawal record deleted');
  };

  const handleUpdateUpiId = (id: string) => {
    if (!tempUpiId.trim()) {
      toast.error('UPI ID cannot be empty');
      return;
    }
    socket.emit("update_withdrawal_upi", { id, upiId: tempUpiId.trim() });
    setEditingUpiId(null);
    toast.success('UPI ID updated');
  };

  const handleDeleteOrder = async (orderId: string) => {
    try {
      await deleteDoc(doc(db, 'orders', orderId));
      toast.success('Order deleted successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `orders/${orderId}`);
      toast.error('Failed to delete order');
    }
  };

  if (!isAuthReady) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (currentUser?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-6 relative">
        <button 
          onClick={toggleDarkMode}
          className="absolute top-6 right-6 p-2 rounded-full hover:bg-black/10 transition-colors text-gray-800"
          aria-label="Toggle Dark Mode"
        >
          {isDarkMode ? <Sun size={24} /> : <Moon size={24} />}
        </button>
        <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-200 w-full max-w-md text-center">
          <div className="flex justify-center mb-6">
            <div className="bg-red-100 p-4 rounded-full">
              <Users size={32} className="text-red-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-red-600 mb-4">Access Denied</h1>
          <p className="text-gray-600 mb-8">
            {currentUser 
              ? `You are logged in as ${currentUser.email}, but you do not have administrative privileges.`
              : "You must be logged in as an administrator to view this dashboard."}
          </p>
          <div className="flex flex-col gap-3">
            <Link to="/" className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition-colors shadow-md">
              Return to Store
            </Link>
            {!currentUser ? (
              <Link to="/account" className="w-full bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition-colors shadow-md">
                Login as Admin
              </Link>
            ) : (
              <Link to="/account" className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-bold hover:bg-gray-50 transition-colors">
                Switch Account
              </Link>
            )}
          </div>
          <p className="mt-6 text-xs text-gray-400">
            Admin access is restricted to authorized emails only.
          </p>
        </div>
      </div>
    );
  }

  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-6 relative">
        <button 
          onClick={toggleDarkMode}
          className="absolute top-6 right-6 p-2 rounded-full hover:bg-black/10 transition-colors text-gray-800"
          aria-label="Toggle Dark Mode"
        >
          {isDarkMode ? <Sun size={24} /> : <Moon size={24} />}
        </button>
        <div className="bg-white p-8 rounded-xl shadow-lg border border-gray-200 w-full max-w-md">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-100 p-4 rounded-full">
              <Users size={32} className="text-blue-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-center text-gray-800 mb-2">Admin Login</h1>
          <p className="text-gray-500 text-center mb-8">Enter password to access dashboard</p>
          
          <form onSubmit={handleUnlock} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input 
                type="password" 
                value={inputPassword}
                onChange={(e) => setInputPassword(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                placeholder="••••••••"
                required
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition-colors shadow-md"
            >
              Unlock Dashboard
            </button>
          </form>
          
          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-gray-500 hover:text-blue-600 transition-colors">
              Return to Store
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6 font-sans">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">
              Real-Time Admin Dashboard
            </h1>
            <button 
              onClick={() => setIsUnlocked(false)}
              className="text-xs text-red-500 hover:text-red-700 font-medium mt-1 underline"
            >
              Lock Dashboard
            </button>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-black/10 transition-colors text-gray-800"
              aria-label="Toggle Dark Mode"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <Link to="/" className="flex items-center gap-2 text-blue-600 hover:underline">
              <ArrowLeft size={20} /> Back to Store
            </Link>
          </div>
        </div>

        {(currentUser?.role === 'admin') && (
          <div className="flex flex-wrap gap-2 mb-8 bg-white p-2 rounded-xl shadow-sm border border-gray-200">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: ShoppingBag, adminOnly: true },
              { id: 'products', label: 'Inventory', icon: LayoutGrid, adminOnly: false },
              { id: 'customers', label: 'Customers', icon: Users, adminOnly: true },
              { id: 'reselling', label: 'Reselling', icon: DollarSign, adminOnly: true },
              { id: 'settings', label: 'Settings', icon: Mail, adminOnly: true }
            ]
            .filter(tab => currentUser?.role === 'admin' || !tab.adminOnly)
            .map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveAdminTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                  activeAdminTab === tab.id 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon size={18} />
                {tab.label}
              </button>
            ))}
          </div>
        )}

        {currentUser?.role === 'admin' && activeAdminTab === 'dashboard' && (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex items-center gap-4">
                <div className="p-4 bg-blue-100 text-blue-600 rounded-lg"><Users size={32} /></div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Active Users</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.activeUsers}</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex items-center gap-4">
                <div className="p-4 bg-green-100 text-green-600 rounded-lg"><ShoppingBag size={32} /></div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Total Orders</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.totalOrders}</p>
                </div>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex items-center gap-4">
                <div className="p-4 bg-orange-100 text-orange-600 rounded-lg"><DollarSign size={32} /></div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Total Revenue</p>
                  <p className="text-3xl font-bold text-gray-900">₹{(stats.totalRevenue || 0).toFixed(2)}</p>
                </div>
              </div>
            </div>

            {/* Orders List moved to Dashboard */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-8">
              <h2 className="text-xl font-bold mb-4">Manage Orders ({orders.length})</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b-2 border-gray-100">
                      <th className="p-3 text-sm font-semibold text-gray-600">Order ID</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Customer</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Total</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Payment Info</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Status</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(o => (
                      <tr key={o.id} className="border-b border-gray-50 hover:bg-gray-50">
                        <td className="p-3 text-xs font-mono">{o.id}</td>
                        <td className="p-3">
                          <p className="text-sm font-medium">{o.address.fullName}</p>
                          <p className="text-[10px] text-gray-500">{o.userEmail}</p>
                          {o.isReselling && (
                            <div className="mt-2 p-2 bg-indigo-50 rounded border border-indigo-100">
                              <p className="text-[10px] text-indigo-700 font-bold uppercase tracking-wider">Reseller Order</p>
                              <p className="text-[10px] text-gray-700 mt-1">
                                <span className="font-bold">Email:</span> {o.resellerEmail}
                              </p>
                              <p className="text-[10px] text-gray-700">
                                <span className="font-bold">Pass:</span> {o.resellerPassword}
                              </p>
                              <p className="text-[10px] text-green-600 font-bold mt-1">
                                Profit: ₹{(o.profitMargin || 0).toFixed(2)}
                              </p>
                              <p className="text-[10px] text-gray-500">
                                Real Price: ₹{(o.realPrice || 0).toFixed(2)}
                              </p>
                            </div>
                          )}
                        </td>
                        <td className="p-3 text-sm font-bold">₹{(o.total || 0).toFixed(2)}</td>
                        <td className="p-3">
                          <p className="text-[10px] text-gray-500 uppercase font-bold">{o.paymentMethod.replace(/_/g, ' ')}</p>
                          {o.paymentDetails?.utr && (
                            <p className="text-xs font-mono text-blue-600 bg-blue-50 px-1 py-0.5 rounded mt-1">UTR: {o.paymentDetails.utr}</p>
                          )}
                        </td>
                        <td className="p-3">
                          <span className={`flex items-center gap-1 w-fit px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                            o.status === 'Delivered' ? 'bg-green-100 text-green-700' :
                            o.status === 'Cancelled' ? 'bg-red-100 text-red-700' :
                            o.status === 'Out for Delivery' ? 'bg-orange-100 text-orange-700' :
                            o.status === 'Shipping' ? 'bg-purple-100 text-purple-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {o.status === 'Delivered' && <CheckCircle className="w-3 h-3" />}
                            {o.status === 'Cancelled' && <XCircle className="w-3 h-3" />}
                            {o.status === 'Out for Delivery' && <ArrowUpRight className="w-3 h-3" />}
                            {o.status === 'Shipping' && <Clock className="w-3 h-3" />}
                            {o.status === 'Ordered' && <ShoppingBag className="w-3 h-3" />}
                            {o.status}
                          </span>
                        </td>
                        <td className="p-3">
                          <select 
                            value={o.status || 'Ordered'}
                            onChange={(e) => handleUpdateStatus(o.id, e.target.value)}
                            className="text-xs p-1 border rounded bg-white"
                          >
                            <option value="Ordered">Ordered</option>
                            <option value="Shipping">Shipping</option>
                            <option value="Out for Delivery">Out for Delivery</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                          <button 
                            onClick={() => handleDeleteOrder(o.id)}
                            className="text-red-500 hover:text-red-700 p-1 ml-2 rounded hover:bg-red-50 transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {currentUser?.role === 'admin' && activeAdminTab === 'customers' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2 text-gray-800">
                <Users size={22} className="text-blue-600" /> Registered Users
              </h2>
              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                {registeredUsers.length === 0 ? (
                  <p className="text-gray-500 text-sm italic text-center py-4">No users registered yet.</p>
                ) : (
                  registeredUsers.map(u => (
                    <div key={u.id} className="p-4 bg-gray-50 rounded-lg border border-gray-100 flex justify-between items-center hover:bg-gray-100 transition-colors">
                      <div className="flex-1 min-w-0 mr-3">
                        <p className="text-sm font-bold text-gray-900 truncate">{u.name}</p>
                        <p className="text-xs text-gray-500 truncate">{u.email}</p>
                        <p className="text-[10px] text-gray-400 mt-1">
                          Joined: {u.createdAt?.toDate ? u.createdAt.toDate().toLocaleDateString() : 'Recently'}
                        </p>
                      </div>
                      <button 
                        onClick={() => handleToggleBan(u.id, u.isBanned || false)}
                        className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-colors ${
                          u.isBanned 
                            ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                            : 'bg-red-100 text-red-700 hover:bg-red-200'
                        }`}
                      >
                        {u.isBanned ? 'Unban' : 'Ban'}
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Add/Edit Product Form */}
          {activeAdminTab === 'products' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Plus size={20} /> {editingProductId ? 'Edit Product' : 'Add New Product'}
            </h2>
            <form onSubmit={handleAddProduct} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-2 border rounded-md" required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sale Price (₹)</label>
                  <input type="number" step="0.01" value={price} onChange={e => setPrice(e.target.value)} className="w-full p-2 border rounded-md" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Original Price (₹) (Optional)</label>
                  <input type="number" step="0.01" value={originalPrice} onChange={e => setOriginalPrice(e.target.value)} className="w-full p-2 border rounded-md" placeholder="For Sale Badge" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Rating (0-5)</label>
                  <input type="number" step="0.1" min="0" max="5" value={rating} onChange={e => setRating(e.target.value)} className="w-full p-2 border rounded-md" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Reviews Count</label>
                  <input type="number" value={reviews} onChange={e => setReviews(e.target.value)} className="w-full p-2 border rounded-md" required />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL 1 (Main)</label>
                <input type="url" value={image1} onChange={e => setImage1(e.target.value)} className="w-full p-2 border rounded-md" required placeholder="https://picsum.photos/seed/..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL 2 (Optional)</label>
                <input type="url" value={image2} onChange={e => setImage2(e.target.value)} className="w-full p-2 border rounded-md" placeholder="https://picsum.photos/seed/..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL 3 (Optional)</label>
                <input type="url" value={image3} onChange={e => setImage3(e.target.value)} className="w-full p-2 border rounded-md" placeholder="https://picsum.photos/seed/..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL 4 (Optional)</label>
                <input type="url" value={image4} onChange={e => setImage4(e.target.value)} className="w-full p-2 border rounded-md" placeholder="https://picsum.photos/seed/..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image URL 5 (Optional)</label>
                <input type="url" value={image5} onChange={e => setImage5(e.target.value)} className="w-full p-2 border rounded-md" placeholder="https://picsum.photos/seed/..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select 
                  value={selectedCategoryId} 
                  onChange={e => setSelectedCategoryId(e.target.value)} 
                  className="w-full p-2 border rounded-md"
                  required
                >
                  <option value="">Select Category</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="prime" checked={prime} onChange={e => setPrime(e.target.checked)} className="w-4 h-4 text-blue-600" />
                <label htmlFor="prime" className="text-sm font-medium text-gray-700">Prime Delivery</label>
              </div>
              <div className="flex gap-2">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors font-medium">
                  {editingProductId ? 'Update Product' : 'Add Product'}
                </button>
                {editingProductId && (
                  <button type="button" onClick={cancelEdit} className="flex-1 bg-gray-200 text-gray-800 py-2 rounded-md hover:bg-gray-300 transition-colors font-medium">
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
          )}

          {currentUser?.role === 'admin' && activeAdminTab === 'customers' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Tag size={20} /> Add Promo Code</h2>
              <form onSubmit={handleAddPromoCode} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Code</label>
                  <input type="text" value={promoCode} onChange={e => setPromoCode(e.target.value)} className="w-full p-2 border rounded-md" required placeholder="e.g. SAVE10" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Discount</label>
                  <input type="number" value={discount} onChange={e => setDiscount(e.target.value)} className="w-full p-2 border rounded-md" required />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                  <select value={discountType} onChange={e => setDiscountType(e.target.value)} className="w-full p-2 border rounded-md">
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                  </select>
                </div>
                <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700 transition-colors font-medium">Add Promo Code</button>
              </form>
            </div>
          )}

          {currentUser?.role === 'admin' && activeAdminTab === 'customers' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><LayoutGrid size={20} /> Reviews Management</h2>
              <button 
                onClick={() => setShowReviewsList(!showReviewsList)}
                className={`w-full py-2 rounded-md font-medium transition-colors ${showReviewsList ? 'bg-gray-200 text-gray-800' : 'bg-green-600 text-white hover:bg-green-700'}`}
              >
                {showReviewsList ? 'Hide Reviews List' : 'Show All Reviews'}
              </button>
              <p className="text-[10px] text-gray-500 mt-2 text-center">Manage both real and fake reviews here</p>
            </div>
          )}

          {currentUser?.role === 'admin' && activeAdminTab === 'customers' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Tag size={20} /> Manage Promo Codes</h2>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {promoCodes.length === 0 ? (
                  <p className="text-gray-500 text-sm italic">No promo codes yet.</p>
                ) : (
                  promoCodes.map(p => (
                    <div key={p.id} className="p-3 bg-gray-50 rounded-lg border border-gray-100 flex justify-between items-center">
                      <div>
                        <p className="text-sm font-bold text-gray-800">{p.code}</p>
                        <p className="text-xs text-gray-500">{p.discount} {p.type === 'percentage' ? '%' : '₹'}</p>
                      </div>
                      <button 
                        onClick={() => handleDeletePromoCode(p.id)}
                        className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Account Manager creation section removed */}

          {currentUser?.role === 'admin' && activeAdminTab === 'reselling' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Users size={20} /> Reseller Access</h2>
              <form onSubmit={handleAddReseller} className="space-y-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input 
                    type="email" 
                    value={newResellerEmail} 
                    onChange={e => setNewResellerEmail(e.target.value)} 
                    className="w-full p-2 border rounded-md" 
                    required 
                    placeholder="Enter reseller email" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                  <input 
                    type="text" 
                    value={newResellerPassword} 
                    onChange={e => setNewResellerPassword(e.target.value)} 
                    className="w-full p-2 border rounded-md" 
                    required 
                    placeholder="Enter reseller password" 
                  />
                </div>
                <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700 transition-colors font-medium">Add Reseller</button>
              </form>
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                {resellers.length === 0 ? (
                  <p className="text-gray-500 text-sm italic">No resellers yet.</p>
                ) : (
                  resellers.map((r, idx) => (
                    <div key={idx} className={`p-3 rounded-lg border flex flex-col gap-2 ${r.isBanned ? 'bg-red-50 border-red-100' : 'bg-gray-50 border-gray-100'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-bold text-gray-800">{r.email}</p>
                          <p className="text-xs text-gray-500 font-mono">{r.password}</p>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${r.isBanned ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                          {r.isBanned ? 'BANNED' : 'ACTIVE'}
                        </span>
                      </div>
                      <div className="flex gap-2 justify-end mt-2">
                        <button 
                          onClick={() => handleToggleBanReseller(r.email)}
                          className={`text-xs font-medium px-3 py-1 rounded transition-colors ${r.isBanned ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-orange-100 text-orange-700 hover:bg-orange-200'}`}
                        >
                          {r.isBanned ? 'Unban' : 'Ban'}
                        </button>
                        <button 
                          onClick={() => handleDeleteReseller(r.email)}
                          className="text-xs font-medium px-3 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200 transition-colors"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {currentUser?.role === 'admin' && activeAdminTab === 'reselling' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><DollarSign size={20} /> Reseller Earnings</h2>
              <form onSubmit={handleAddEarning} className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Reseller</label>
                  <select 
                    value={selectedResellerEmail} 
                    onChange={e => setSelectedResellerEmail(e.target.value)} 
                    className="w-full p-2 border rounded-md"
                    required
                  >
                    <option value="">Select Reseller</option>
                    {resellers.map((r, idx) => (
                      <option key={idx} value={r.email}>{r.email}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Amount (₹)</label>
                  <input 
                    type="number" 
                    value={earningAmount} 
                    onChange={e => setEarningAmount(e.target.value)} 
                    className="w-full p-2 border rounded-md" 
                    required 
                    placeholder="e.g. 500" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <input 
                    type="text" 
                    value={earningDescription} 
                    onChange={e => setEarningDescription(e.target.value)} 
                    className="w-full p-2 border rounded-md" 
                    required 
                    placeholder="e.g. Commission for Order #123" 
                  />
                </div>
                <button type="submit" className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition-colors font-medium">Add Earning</button>
              </form>

              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                <h3 className="text-sm font-bold text-gray-700 mb-2">Recent Earnings</h3>
                {resellerEarnings.length === 0 ? (
                  <p className="text-gray-500 text-sm italic">No earnings recorded yet.</p>
                ) : (
                  [...resellerEarnings].reverse().map((e) => (
                    <div key={e.id} className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="text-xs font-bold text-gray-800">{e.email}</p>
                          <p className="text-[10px] text-gray-500">{new Date(e.date).toLocaleString()}</p>
                        </div>
                        <p className="text-sm font-bold text-green-600">₹{e.amount.toFixed(2)}</p>
                      </div>
                      <p className="text-xs text-gray-600 mb-3">{e.description}</p>
                      <div className="flex items-center justify-between">
                        <select 
                          value={e.status}
                          onChange={(ev) => handleUpdateEarningStatus(e.id, ev.target.value as 'pending' | 'completed')}
                          className={`text-[10px] font-bold px-2 py-1 rounded border ${
                            e.status === 'completed' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-yellow-100 text-yellow-700 border-yellow-200'
                          }`}
                        >
                          <option value="pending">PENDING</option>
                          <option value="completed">COMPLETED</option>
                        </select>
                        <button 
                          onClick={() => handleDeleteEarning(e.id)}
                          className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {currentUser?.role === 'admin' && activeAdminTab === 'reselling' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><DollarSign size={20} /> Reseller Withdrawals</h2>
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                {resellerWithdrawals.length === 0 ? (
                  <p className="text-gray-500 text-sm italic">No withdrawal requests yet.</p>
                ) : (
                  [...resellerWithdrawals].reverse().map((w) => (
                    <div key={w.id} className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="text-xs font-bold text-gray-800">{w.email}</p>
                          <p className="text-[10px] text-gray-500">{new Date(w.date).toLocaleString()}</p>
                        </div>
                        <p className="text-sm font-bold text-red-600">₹{w.amount.toFixed(2)}</p>
                      </div>
                      <div className="bg-white p-2 rounded border border-gray-200 mb-3">
                        <div className="flex justify-between items-center mb-1">
                          <p className="text-[10px] text-gray-500 uppercase font-bold">UPI ID</p>
                          {editingUpiId === w.id ? (
                            <div className="flex gap-1">
                              <button 
                                onClick={() => handleUpdateUpiId(w.id)}
                                className="text-[10px] bg-green-500 text-white px-2 py-0.5 rounded hover:bg-green-600"
                              >
                                Save
                              </button>
                              <button 
                                onClick={() => setEditingUpiId(null)}
                                className="text-[10px] bg-gray-500 text-white px-2 py-0.5 rounded hover:bg-gray-600"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button 
                              onClick={() => {
                                setEditingUpiId(w.id);
                                setTempUpiId(w.upiId);
                              }}
                              className="text-[10px] text-blue-600 hover:underline"
                            >
                              Edit
                            </button>
                          )}
                        </div>
                        {editingUpiId === w.id ? (
                          <input 
                            type="text"
                            value={tempUpiId}
                            onChange={(e) => setTempUpiId(e.target.value)}
                            className="w-full text-xs font-mono p-1 border rounded"
                            autoFocus
                          />
                        ) : (
                          <p className="text-xs font-mono text-blue-600 select-all">{w.upiId}</p>
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <select 
                          value={w.status}
                          onChange={(ev) => handleUpdateWithdrawalStatus(w.id, ev.target.value as any)}
                          className={`text-[10px] font-bold px-2 py-1 rounded border ${
                            w.status === 'completed' ? 'bg-green-100 text-green-700 border-green-200' : 
                            w.status === 'rejected' ? 'bg-red-100 text-red-700 border-red-200' :
                            'bg-yellow-100 text-yellow-700 border-yellow-200'
                          }`}
                        >
                          <option value="pending">PENDING</option>
                          <option value="completed">COMPLETED</option>
                          <option value="rejected">REJECTED</option>
                        </select>
                        <button 
                          onClick={() => handleDeleteWithdrawal(w.id)}
                          className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {(currentUser?.role === 'admin') && activeAdminTab === 'products' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><LayoutGrid size={20} /> Add New Category</h2>
              <form onSubmit={handleAddCategory} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category Name</label>
                  <input type="text" value={catName} onChange={e => setCatName(e.target.value)} className="w-full p-2 border rounded-md" required placeholder="e.g. Mobiles" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
                  <input type="url" value={catImage} onChange={e => setCatImage(e.target.value)} className="w-full p-2 border rounded-md" required placeholder="https://picsum.photos/seed/..." />
                </div>
                <button type="submit" className="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700 transition-colors font-medium">Add Category</button>
              </form>
            </div>
          )}

          {(currentUser?.role === 'admin') && activeAdminTab === 'products' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><ImageIcon size={20} /> Add New Slider</h2>
              <form onSubmit={handleAddSlider} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Slider Image URL</label>
                  <input type="url" value={sliderImage} onChange={e => setSliderImage(e.target.value)} className="w-full p-2 border rounded-md" required placeholder="https://picsum.photos/seed/..." />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Target Link (Optional)</label>
                  <input type="text" value={sliderLink} onChange={e => setSliderLink(e.target.value)} className="w-full p-2 border rounded-md" placeholder="/category/1 or #" />
                </div>
                <button type="submit" className="w-full bg-teal-600 text-white py-2 rounded-md hover:bg-teal-700 transition-colors font-medium">Add Slider</button>
              </form>
            </div>
          )}



          {/* Brand & Theme section removed as requested */}

          {(currentUser?.role === 'admin') && activeAdminTab === 'products' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><LayoutGrid size={20} /> Sponsored Ad Code</h2>
              <form onSubmit={handleUpdateAdCode} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Ad Code (HTML/Script)</label>
                  <textarea value={adCode} onChange={e => setAdCode(e.target.value)} className="w-full p-2 border rounded-md" rows={6} placeholder="Enter ad code here..." />
                </div>
                <button type="submit" className="w-full bg-yellow-600 text-white py-2 rounded-md hover:bg-yellow-700 transition-colors font-medium">Update Ad Code</button>
              </form>
            </div>
          )}

          {currentUser?.role === 'admin' && activeAdminTab === 'settings' && (
            <>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><Users size={20} /> Admin Security</h2>
                <form onSubmit={handleUpdateAdminPassword} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">New Admin Password</label>
                    <input 
                      type="text" 
                      value={newAdminPassword} 
                      onChange={e => setNewAdminPassword(e.target.value)} 
                      className="w-full p-2 border rounded-md" 
                      placeholder="Enter new password..." 
                      required 
                    />
                    <p className="text-[10px] text-gray-500 mt-1">Default password is: admin123</p>
                  </div>
                  <button type="submit" className="w-full bg-red-600 text-white py-2 rounded-md hover:bg-red-700 transition-colors font-medium">Update Password</button>
                </form>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 h-fit">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><LayoutGrid size={20} /> Brand Settings</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Brand Name</label>
                    <input 
                      type="text" 
                      value={brandName} 
                      onChange={e => setBrandName(e.target.value)} 
                      className="w-full p-2 border rounded-md" 
                      placeholder="Enter brand name..." 
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Primary Color</label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={primaryColor} 
                          onChange={e => setPrimaryColor(e.target.value)} 
                          className="w-10 h-10 border rounded-md p-1 cursor-pointer" 
                        />
                        <input 
                          type="text" 
                          value={primaryColor} 
                          onChange={e => setPrimaryColor(e.target.value)} 
                          className="flex-1 p-2 border rounded-md text-xs" 
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Secondary Color</label>
                      <div className="flex gap-2">
                        <input 
                          type="color" 
                          value={secondaryColor} 
                          onChange={e => setSecondaryColor(e.target.value)} 
                          className="w-10 h-10 border rounded-md p-1 cursor-pointer" 
                        />
                        <input 
                          type="text" 
                          value={secondaryColor} 
                          onChange={e => setSecondaryColor(e.target.value)} 
                          className="flex-1 p-2 border rounded-md text-xs" 
                        />
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={handleUpdateBrandConfig} 
                    className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors font-medium"
                  >
                    Update Brand Configuration
                  </button>
                </div>
              </div>
            </>
          )}

          {(currentUser?.role === 'admin') && activeAdminTab === 'products' && (
            <>
              {/* Sliders List */}
              <div className="lg:col-span-3 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h2 className="text-xl font-bold mb-4">Manage Sliders ({sliders.length})</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {sliders.map(s => (
                    <div key={s.id} className="relative group border rounded-lg p-2 hover:shadow-md transition-shadow">
                      <img src={s.image} alt="Slider" className="w-full h-32 object-cover rounded mb-2" referrerPolicy="no-referrer" />
                      <p className="text-xs text-gray-500 truncate">Link: {s.link}</p>
                      <button 
                        onClick={() => handleDeleteSlider(s.id)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Categories List */}
              <div className="lg:col-span-3 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h2 className="text-xl font-bold mb-4">Manage Categories ({categories.length})</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {categories.map(c => (
                    <div key={c.id} className="relative group border rounded-lg p-2 hover:shadow-md transition-shadow">
                      <img src={c.image} alt={c.name} className="w-full aspect-square object-cover rounded mb-2" referrerPolicy="no-referrer" />
                      <p className="text-sm font-bold text-center truncate">{c.name}</p>
                      <button 
                        onClick={() => handleDeleteCategory(c.id)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Products List */}
          {activeAdminTab === 'products' && (
            <div className="lg:col-span-3 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <h2 className="text-xl font-bold mb-4">Manage Products ({products.length})</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b-2 border-gray-100">
                    <th className="p-3 text-sm font-semibold text-gray-600">Image</th>
                    <th className="p-3 text-sm font-semibold text-gray-600">Title</th>
                    <th className="p-3 text-sm font-semibold text-gray-600">Price</th>
                    <th className="p-3 text-sm font-semibold text-gray-600">Rating</th>
                    <th className="p-3 text-sm font-semibold text-gray-600">Reviews</th>
                    <th className="p-3 text-sm font-semibold text-gray-600">Prime</th>
                    <th className="p-3 text-sm font-semibold text-gray-600 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50">
                      <td className="p-3">
                        <div className="w-12 h-12 bg-gray-50 rounded-lg flex items-center justify-center p-1 border border-gray-100">
                          <img src={p.image} alt={p.title} className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                        </div>
                      </td>
                      <td className="p-3 text-sm font-medium text-gray-800 max-w-[200px] truncate">{p.title}</td>
                      <td className="p-3 text-sm font-bold text-gray-900">₹{(p.price || 0).toFixed(2)}</td>
                      <td className="p-3 text-sm">
                        <div className="flex items-center gap-1">
                          <span className="text-yellow-500 text-xs font-bold">{p.rating || 0}</span>
                          <span className="text-yellow-400">★</span>
                        </div>
                      </td>
                      <td className="p-3 text-sm text-gray-500">{p.reviews || 0}</td>
                      <td className="p-3 text-sm">{p.prime ? '✅' : '❌'}</td>
                      <td className="p-3 text-center flex justify-center gap-2">
                        <button 
                          onClick={() => setReviewModalProductId(p.id)} 
                          className="bg-green-50 text-green-600 hover:bg-green-600 hover:text-white p-2 rounded-lg transition-all duration-200 shadow-sm border border-green-100"
                          title="Add Review"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                        </button>
                        <button 
                          onClick={() => handleEditProduct(p)} 
                          className="bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white p-2 rounded-lg transition-all duration-200 shadow-sm border border-blue-100"
                          title="Edit Product"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        </button>
                        <button 
                          onClick={() => handleDelete(p.id)} 
                          className="bg-red-50 text-red-600 hover:bg-red-600 hover:text-white p-2 rounded-lg transition-all duration-200 shadow-sm border border-red-100"
                          title="Delete Product"
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          )}
        </div>
      </div>

      {/* Review Modal */}
      {reviewModalProductId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
            <h3 className="text-xl font-bold mb-4">Add Custom Review</h3>
            <form onSubmit={handleAddReview} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">User Name</label>
                <input type="text" value={reviewUserName} onChange={e => setReviewUserName(e.target.value)} className="w-full p-2 border rounded-md" required placeholder="e.g. John Doe" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">User Photo URL (Optional)</label>
                <input type="url" value={reviewUserPhoto} onChange={e => setReviewUserPhoto(e.target.value)} className="w-full p-2 border rounded-md" placeholder="https://..." />
                <p className="text-xs text-gray-500 mt-1">Leave empty to auto-generate from name</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rating (1-5)</label>
                <input type="number" min="1" max="5" step="0.5" value={reviewRating} onChange={e => setReviewRating(e.target.value)} className="w-full p-2 border rounded-md" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Comment</label>
                <textarea value={reviewComment} onChange={e => setReviewComment(e.target.value)} className="w-full p-2 border rounded-md" rows={3} required placeholder="Write review here..."></textarea>
              </div>
              <div className="flex gap-2 pt-2">
                <button type="submit" className="flex-1 bg-green-600 text-white py-2 rounded-md hover:bg-green-700 font-medium">Add Review</button>
                <button type="button" onClick={() => setReviewModalProductId(null)} className="flex-1 bg-gray-200 text-gray-800 py-2 rounded-md hover:bg-gray-300 font-medium">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reviews List Modal */}
      {showReviewsList && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-4xl max-h-[80vh] overflow-hidden flex flex-col shadow-xl">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-4">
                <h3 className="text-xl font-bold">Manage All Reviews ({allReviews.length})</h3>
                {allReviews.some(r => r.isAdminReview) && (
                  <button 
                    onClick={async () => {
                      const fakeReviews = allReviews.filter(r => r.isAdminReview);
                      if (fakeReviews.length === 0) return;
                      
                      const confirmed = true; // For now, bypass confirm to ensure it works
                      if (confirmed) {
                        for (const r of fakeReviews) {
                          try {
                            await deleteDoc(doc(db, 'reviews', r.id));
                          } catch (error) {
                            console.error('Error deleting fake review:', error);
                          }
                        }
                        toast.success('All fake reviews deleted');
                      }
                    }}
                    className="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full hover:bg-red-200 font-bold transition-colors"
                  >
                    Delete All Fake
                  </button>
                )}
              </div>
              <button onClick={() => setShowReviewsList(false)} className="text-gray-500 hover:text-gray-700">✕</button>
            </div>
            <div className="overflow-y-auto flex-1 pr-2">
              {allReviews.length === 0 ? (
                <p className="text-center text-gray-500 py-8">No reviews found.</p>
              ) : (
                <table className="w-full text-left border-collapse">
                  <thead className="sticky top-0 bg-white shadow-sm">
                    <tr className="border-b-2 border-gray-100">
                      <th className="p-3 text-sm font-semibold text-gray-600">User</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Product ID</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Rating</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Comment</th>
                      <th className="p-3 text-sm font-semibold text-gray-600">Type</th>
                      <th className="p-3 text-sm font-semibold text-gray-600 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allReviews.map(r => (
                      <tr key={r.id} className="border-b border-gray-50 hover:bg-gray-50">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <img src={r.userPhoto || `https://ui-avatars.com/api/?name=${encodeURIComponent(r.userName)}&background=random`} alt="" className="w-6 h-6 rounded-full" />
                            <span className="text-sm font-medium">{r.userName}</span>
                          </div>
                        </td>
                        <td className="p-3 text-xs font-mono">{r.productId}</td>
                        <td className="p-3 text-sm font-bold text-yellow-500">{r.rating} ★</td>
                        <td className="p-3 text-sm text-gray-600 max-w-[200px] truncate" title={r.text}>{r.text}</td>
                        <td className="p-3">
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${r.isAdminReview ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                            {r.isAdminReview ? 'Fake' : 'Real'}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <button 
                            onClick={() => handleDeleteReview(r.id)}
                            className="text-red-500 hover:text-red-700 p-1 rounded hover:bg-red-50 transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
            <div className="mt-4 pt-4 border-t flex justify-end">
              <button onClick={() => setShowReviewsList(false)} className="bg-gray-200 text-gray-800 px-6 py-2 rounded-md hover:bg-gray-300 font-medium">Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
