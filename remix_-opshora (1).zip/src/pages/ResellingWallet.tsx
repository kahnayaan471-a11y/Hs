import React, { useState, useEffect } from 'react';
import { ArrowLeft, Wallet, ArrowUpRight, Clock, CheckCircle, XCircle, ChevronRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { socket } from '../socket';
import { toast } from 'sonner';

export default function ResellingWallet() {
  const { user, resellerUser, isResellerLoggedIn, resellerLogin } = useAuth();
  const { orders } = useCart();
  const navigate = useNavigate();
  const [balance, setBalance] = useState(0);
  const [earnings, setEarnings] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [resellerOrders, setResellerOrders] = useState<any[]>([]);
  const [resellerEmailInput, setResellerEmailInput] = useState('');
  const [resellerPasswordInput, setResellerPasswordInput] = useState('');
  const [activeTab, setActiveTab] = useState<'earnings' | 'withdrawals' | 'orders'>('earnings');
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [upiId, setUpiId] = useState('');

  const { resellerLogout } = useAuth();

  useEffect(() => {
    if (resellerUser?.email && orders) {
      const filteredOrders = orders.filter(
        (o: any) => o.isReselling && o.resellerEmail === resellerUser.email
      );
      setResellerOrders(filteredOrders);
    } else {
      setResellerOrders([]);
    }
  }, [orders, resellerUser?.email]);

  const fetchWalletData = React.useCallback(() => {
    if (resellerUser?.email) {
      socket.emit('get_reseller_earnings', resellerUser.email, (data: { earnings: any[], withdrawals: any[] }) => {
        const totalEarnings = data.earnings
          .filter(e => e.status === 'completed')
          .reduce((sum, e) => sum + e.amount, 0);
        
        const totalWithdrawn = data.withdrawals
          .filter(w => w.status !== 'rejected')
          .reduce((sum, w) => sum + w.amount, 0);

        setBalance(totalEarnings - totalWithdrawn);
        setEarnings([...data.earnings].reverse());
        setWithdrawals([...data.withdrawals].reverse());
        
        // Pre-fill UPI ID from last withdrawal if not already set
        setUpiId(prev => {
          if (!prev && data.withdrawals.length > 0) {
            return data.withdrawals[data.withdrawals.length - 1].upiId;
          }
          return prev;
        });
      });
    }
  }, [resellerUser?.email]);

  useEffect(() => {
    if (!user) {
      toast.error('Please login to access your reselling wallet');
      navigate('/account');
      return;
    }

    if (isResellerLoggedIn) {
      fetchWalletData();
    }

    socket.on('reseller_earnings_update', fetchWalletData);
    socket.on('reseller_withdrawals_update', fetchWalletData);
    socket.on('orders_update', fetchWalletData);

    return () => {
      socket.off('reseller_earnings_update', fetchWalletData);
      socket.off('reseller_withdrawals_update', fetchWalletData);
      socket.off('orders_update', fetchWalletData);
    };
  }, [user, navigate, isResellerLoggedIn, fetchWalletData]);

  const handleWithdrawRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) return toast.error('Invalid amount');
    if (amount > balance) return toast.error('Insufficient balance');
    if (!upiId) return toast.error('Please enter UPI ID');

    socket.emit('request_withdrawal', {
      email: resellerUser?.email,
      amount,
      upiId
    }, (res: any) => {
      if (res.success) {
        toast.success('Withdrawal request submitted!');
        setIsWithdrawModalOpen(false);
        setWithdrawAmount('');
        setUpiId('');
        fetchWalletData();
      } else {
        toast.error(res.message);
      }
    });
  };

  const handleResellerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resellerEmailInput || !resellerPasswordInput) return;
    
    socket.emit('verify_reseller', { email: resellerEmailInput, password: resellerPasswordInput }, (res: any) => {
      if (res.success) {
        toast.success('Access granted! Welcome to your Reselling Wallet.');
        resellerLogin(resellerEmailInput);
      } else {
        toast.error(res.message || 'Invalid email or password.');
      }
    });
  };

  if (!isResellerLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white p-6 rounded-2xl shadow-lg w-full max-w-md">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-100 p-4 rounded-full">
              <Wallet size={32} className="text-blue-600" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center mb-2">Reseller Access</h2>
          <p className="text-gray-500 text-center mb-6">Please verify your reseller credentials to access your wallet.</p>
          
          <form onSubmit={handleResellerSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                value={resellerEmailInput}
                onChange={(e) => setResellerEmailInput(e.target.value)}
                placeholder="Enter your reseller email"
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input
                type="password"
                value={resellerPasswordInput}
                onChange={(e) => setResellerPasswordInput(e.target.value)}
                placeholder="Enter your reseller password"
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors mt-4"
            >
              Verify Access
            </button>
            <button
              type="button"
              onClick={() => navigate('/menu')}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-xl font-bold hover:bg-gray-200 transition-colors"
            >
              Cancel
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-blue-600 text-white p-4 pb-12 rounded-b-3xl shadow-md">
        <div className="flex items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-3">
            <Link to="/menu" className="p-2 hover:bg-blue-700 rounded-full transition-colors">
              <ArrowLeft size={24} />
            </Link>
            <h1 className="text-xl font-bold">Reselling Wallet</h1>
          </div>
          <button 
            onClick={() => {
              resellerLogout();
              toast.success('Logged out from reseller account');
            }}
            className="text-xs bg-blue-700 hover:bg-blue-800 px-3 py-1.5 rounded-lg font-bold transition-colors"
          >
            Logout
          </button>
        </div>
        
        <div className="text-center">
          <p className="text-blue-100 text-sm mb-1">Total Balance</p>
          <h2 className="text-4xl font-bold mb-2">₹{balance.toFixed(2)}</h2>
          <p className="text-blue-200 text-xs">Available for withdrawal</p>
          <p className="text-blue-300/80 text-[10px] mt-1 font-medium">minimum 5/10 order complete</p>
        </div>
      </div>

      <div className="px-4 -mt-6 relative z-10">
        <div className="bg-white rounded-2xl shadow-sm p-4 flex gap-4 mb-6">
          <button 
            onClick={() => setIsWithdrawModalOpen(true)}
            className="flex-1 bg-blue-50 text-blue-700 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-100 transition-colors"
          >
            <ArrowUpRight size={18} />
            Withdraw
          </button>
          <button 
            onClick={() => setActiveTab(activeTab === 'earnings' ? 'withdrawals' : 'earnings')}
            className="flex-1 bg-gray-50 text-gray-700 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-gray-100 transition-colors"
          >
            <Clock size={18} />
            {activeTab === 'earnings' ? 'Withdrawals' : 'Earnings'}
          </button>
        </div>

        <div className="flex items-center justify-between mb-4 px-1">
          <h3 className="font-bold text-gray-800">
            {activeTab === 'earnings' ? 'Earnings History' : activeTab === 'withdrawals' ? 'Withdrawal History' : 'Reseller Orders'}
          </h3>
          <div className="flex bg-gray-200 p-1 rounded-lg">
            <button 
              onClick={() => setActiveTab('earnings')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${activeTab === 'earnings' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
            >
              Earnings
            </button>
            <button 
              onClick={() => setActiveTab('withdrawals')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${activeTab === 'withdrawals' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
            >
              Withdrawals
            </button>
            <button 
              onClick={() => setActiveTab('orders')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${activeTab === 'orders' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500'}`}
            >
              Orders
            </button>
          </div>
        </div>
        
        <div className="space-y-3">
          {activeTab === 'earnings' ? (
            earnings.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl text-center text-gray-500">
                No earnings yet
              </div>
            ) : (
              earnings.map((tx) => (
                <div key={tx.id} className="bg-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-full ${tx.status === 'completed' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}`}>
                      {tx.status === 'completed' ? <CheckCircle size={20} /> : <Clock size={20} />}
                    </div>
                    <div>
                      <p className="font-bold text-sm text-gray-800">{tx.description}</p>
                      <p className="text-xs text-gray-500">{new Date(tx.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${tx.status === 'completed' ? 'text-green-600' : 'text-gray-800'}`}>
                      +₹{tx.amount.toFixed(2)}
                    </p>
                    <p className={`text-[10px] flex items-center justify-end gap-1 mt-1 uppercase font-bold ${
                      tx.status === 'completed' ? 'text-green-500' : 'text-yellow-600'
                    }`}>
                      {tx.status === 'completed' ? 'Completed' : 'Pending'}
                    </p>
                  </div>
                </div>
              ))
            )
          ) : activeTab === 'withdrawals' ? (
            withdrawals.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl text-center text-gray-500">
                No withdrawals yet
              </div>
            ) : (
              withdrawals.map((tx) => (
                <div key={tx.id} className="bg-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-full ${
                      tx.status === 'completed' ? 'bg-green-100 text-green-600' : 
                      tx.status === 'rejected' ? 'bg-red-100 text-red-600' : 
                      'bg-yellow-100 text-yellow-600'
                    }`}>
                      {tx.status === 'completed' ? <CheckCircle size={20} /> : 
                       tx.status === 'rejected' ? <XCircle size={20} /> : 
                       <Clock size={20} />}
                    </div>
                    <div>
                      <p className="font-bold text-sm text-gray-800">Withdrawal</p>
                      <p className="text-xs text-gray-500">{new Date(tx.date).toLocaleDateString()}</p>
                      <p className="text-[10px] text-gray-400">UPI: {tx.upiId}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-red-600">
                      -₹{tx.amount.toFixed(2)}
                    </p>
                    <p className={`text-[10px] flex items-center justify-end gap-1 mt-1 uppercase font-bold ${
                      tx.status === 'completed' ? 'text-green-500' : 
                      tx.status === 'rejected' ? 'text-red-500' : 
                      'text-yellow-600'
                    }`}>
                      {tx.status === 'completed' ? 'Completed' : 
                       tx.status === 'rejected' ? 'Rejected' : 
                       'Pending'}
                    </p>
                  </div>
                </div>
              ))
            )
          ) : (
            resellerOrders.length === 0 ? (
              <div className="bg-white p-8 rounded-2xl text-center text-gray-500">
                No reseller orders yet
              </div>
            ) : (
              resellerOrders.map((order) => (
                <div key={order.id} className="bg-white p-4 rounded-2xl shadow-sm space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest">Order ID</p>
                      <p className="text-xs font-mono font-bold text-gray-900">#{order.id.slice(-8)}</p>
                    </div>
                    <div className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 
                      order.status === 'Cancelled' ? 'bg-red-100 text-red-700' : 
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {order.status}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 py-2 border-y border-gray-50">
                    <img src={order.items?.[0]?.image} alt="" className="w-10 h-10 object-contain" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-gray-900 truncate">{order.items?.[0]?.title}</p>
                      <p className="text-[10px] text-gray-500">{order.items?.length} items</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[10px] text-gray-400">Customer</p>
                      <p className="text-xs font-bold text-gray-900">{order.address?.fullName}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-gray-400">Your Profit</p>
                      <p className="text-sm font-bold text-green-600">₹{(order.profitMargin || 0).toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              ))
            )
          )}
        </div>
      </div>

      {/* Withdraw Modal */}
      {isWithdrawModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100] p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md animate-in zoom-in duration-200">
            <h2 className="text-xl font-bold mb-2">Request Withdrawal</h2>
            <p className="text-sm text-gray-500 mb-6">Enter the amount and your UPI ID to receive funds.</p>
            
            <form onSubmit={handleWithdrawRequest} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Amount (Available: ₹{balance.toFixed(2)})</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-bold">₹</span>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none font-bold"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">UPI ID</label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="example@upi"
                  className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                />
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsWithdrawModalOpen(false)}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-bold hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
