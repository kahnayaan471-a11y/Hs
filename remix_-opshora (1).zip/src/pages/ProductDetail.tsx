import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Star, Check, ArrowLeft, ShieldCheck, Truck, RotateCcw, Info, ShoppingCart, Share2, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { socket } from '../socket';
import { Product } from '../types';
import Header from '../components/Header';
import PaymentModal from '../components/PaymentModal';
import AddressModal from '../components/AddressModal';
import AuthModal from '../components/AuthModal';
import CartDrawer from '../components/CartDrawer';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useWishlist } from '../context/WishlistContext';
import { db } from '../firebase';
import { collection, addDoc, query, where, onSnapshot, orderBy, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../utils/firestoreError';
import { useTheme } from '../hooks/useTheme';
import { Trash2 } from 'lucide-react';

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, cartCount, cartTotal, clearCart, cartItems, placeOrder } = useCart();
  const { user, login, isLoggedIn } = useAuth();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const { brandName } = useTheme();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState<any>(null);
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);
  const [activeImage, setActiveImage] = useState<string>('');
  
  const [reviews, setReviews] = useState<any[]>([]);
  const [showAllReviews, setShowAllReviews] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, text: '', image: '' });

  useEffect(() => {
    if (!id || isNaN(Number(id))) return;
    const q = query(collection(db, 'reviews'), where('productId', '==', Number(id)), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setReviews(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'reviews'));
    return () => unsubscribe();
  }, [id]);

  const handleAddReview = async () => {
    if (!isLoggedIn) return toast.info('Please sign in to add a review');
    if (!newReview.text.trim()) return toast.error('Review text cannot be empty');
    
    try {
      await addDoc(collection(db, 'reviews'), {
        productId: Number(id),
        userId: user?.uid,
        userName: user?.name || 'Anonymous',
        userPhoto: user?.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || 'Anonymous')}&background=random`,
        rating: newReview.rating,
        text: newReview.text,
        image: newReview.image,
        createdAt: serverTimestamp()
      });
      setNewReview({ rating: 5, text: '', image: '' });
      toast.success('Review added successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'reviews');
      toast.error('Failed to add review');
    }
  };

  const handleDeleteReview = async (reviewId: string) => {
    try {
      await deleteDoc(doc(db, 'reviews', reviewId));
      toast.success('Review deleted successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `reviews/${reviewId}`);
      toast.error('Failed to delete review');
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewReview(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    const handleInitialData = (data: { products: Product[] }) => {
      const foundProduct = data.products.find(p => p.id === Number(id));
      setProduct(foundProduct || null);
      if (foundProduct) setActiveImage(foundProduct.image);
      setLoading(false);
    };

    const handleProductsUpdate = (updatedProducts: Product[]) => {
      const foundProduct = updatedProducts.find(p => p.id === Number(id));
      setProduct(foundProduct || null);
      if (foundProduct && !activeImage) setActiveImage(foundProduct.image);
    };

    socket.on('initial_data', handleInitialData);
    socket.on('products_update', handleProductsUpdate);

    if (socket.connected) {
      socket.disconnect();
      socket.connect();
    }

    return () => {
      socket.off('initial_data', handleInitialData);
      socket.off('products_update', handleProductsUpdate);
    };
  }, [id]);

  const handleAddToCart = () => {
    if (!product) return;
    addToCart(product);
    toast.success('Added to cart!');
  };

  const handleCheckout = async () => {
    if (cartCount === 0 && !product) return toast.error('Cart is empty');
    
    if (!isLoggedIn) {
      setIsAuthModalOpen(true);
      return;
    }
    
    // If it's a direct "Buy Now" from product page, ensure product is in cart
    if (product && !cartItems.find(item => item.id === product.id)) {
      addToCart(product);
    }

    setIsCartDrawerOpen(false);
    setIsAddressModalOpen(true);
  };

  const handleAddressConfirm = (address: any) => {
    setDeliveryAddress(address);
    setIsAddressModalOpen(false);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentConfirm = (method: string, details?: { utr?: string; isReselling?: boolean; profitMargin?: number; resellerEmail?: string; resellerPassword?: string; realPrice?: number }) => {
    if (!user || !deliveryAddress) return;

    // Clean address to avoid circular structure errors
    const cleanAddress = {
      fullName: String(deliveryAddress.fullName || ''),
      phone: String(deliveryAddress.phone || ''),
      houseNo: String(deliveryAddress.houseNo || ''),
      area: String(deliveryAddress.area || ''),
      landmark: String(deliveryAddress.landmark || ''),
      pincode: String(deliveryAddress.pincode || ''),
      city: String(deliveryAddress.city || ''),
      state: String(deliveryAddress.state || ''),
      type: (deliveryAddress.type === 'work' ? 'work' : 'home') as 'home' | 'work'
    };

    // Clean data to avoid circular structure errors and break any potential proxies
    const cleanDetails = details ? JSON.parse(JSON.stringify({
      utr: details.utr,
      isReselling: details.isReselling,
      profitMargin: details.profitMargin,
      resellerEmail: details.resellerEmail,
      resellerPassword: details.resellerPassword,
      realPrice: details.realPrice
    })) : {};

    socket.emit('place_order', {
      total: Number((cartTotal || (product?.price || 0)) + (cleanDetails.profitMargin || 0)),
      address: cleanAddress,
      paymentMethod: method,
      ...cleanDetails
    });
    
    // Save order to context/local storage
    placeOrder(cleanAddress, method, cleanDetails);
    
    setIsPaymentModalOpen(false);
    toast.success(`Order placed successfully! Delivering to ${cleanAddress.fullName}`);
    navigate('/orders');
  };

  const handleShare = async () => {
    if (!product) return;
    const shareData = {
      title: product.title,
      text: `Check out ${product.title} on Amazon!`,
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success('Link copied to clipboard!');
      }
    } catch (err) {
      // User canceled or share failed silently
    }
  };

  const handleWishlist = () => {
    if (!product) return;
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl font-bold mb-4">Product not found</h1>
        <Link to="/" className="text-blue-600 hover:underline flex items-center gap-2">
          <ArrowLeft size={20} /> Back to Storefront
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white font-sans">
      <Header 
        cartCount={cartCount} 
        cartTotal={cartTotal} 
        onCheckout={() => setIsCartDrawerOpen(true)} 
      />

      <CartDrawer 
        isOpen={isCartDrawerOpen}
        onClose={() => setIsCartDrawerOpen(false)}
        onCheckout={handleCheckout}
      />

      <AddressModal 
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        onConfirm={handleAddressConfirm}
      />

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onConfirm={handlePaymentConfirm}
        onEditAddress={() => {
          setIsPaymentModalOpen(false);
          setIsAddressModalOpen(true);
        }}
        totalAmount={cartTotal || (product?.price || 0)}
        deliveryAddress={deliveryAddress}
      />

      <div className="max-w-[1500px] mx-auto px-4 py-4 md:py-8">
        <nav className="flex items-center gap-2 text-xs text-gray-600 mb-6 overflow-x-auto whitespace-nowrap pb-2">
          <Link to="/" className="hover:text-orange-600 hover:underline">Electronics</Link>
          <span>›</span>
          <Link to="/" className="hover:text-orange-600 hover:underline">Computers & Accessories</Link>
          <span>›</span>
          <span className="font-bold text-gray-800 truncate">{product.title}</span>
        </nav>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12">
          {/* Image Column */}
          <div className="md:col-span-5 lg:col-span-4">
            <div className="sticky top-4">
              <div className="border border-gray-100 rounded-lg p-4 flex items-center justify-center bg-white aspect-square overflow-hidden mb-4">
                <img 
                  src={activeImage || product.image} 
                  alt={product.title} 
                  className="max-h-full max-w-full object-contain mix-blend-multiply"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {(product.images && product.images.length > 0 ? product.images : [product.image, product.image, product.image, product.image]).map((img, i) => (
                  <div 
                    key={i} 
                    onClick={() => setActiveImage(img)}
                    className={`w-16 h-16 border rounded p-1 flex-shrink-0 cursor-pointer transition-colors ${activeImage === img ? 'border-orange-500 shadow-sm' : 'border-gray-200 hover:border-orange-500'}`}
                  >
                    <img src={img} alt="" className="w-full h-full object-contain mix-blend-multiply" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Details Column */}
          <div className="md:col-span-7 lg:col-span-5 relative">
            <div className="absolute top-0 right-0 flex gap-2 z-10">
              <button 
                onClick={handleShare}
                className="flex items-center justify-center w-10 h-10 bg-white border border-gray-200 text-gray-600 hover:text-blue-600 hover:border-blue-200 hover:bg-blue-50 rounded-full transition-all shadow-sm hover:shadow-md"
                title="Share"
              >
                <Share2 size={18} />
              </button>
              <button 
                onClick={handleWishlist}
                className="flex items-center justify-center w-10 h-10 bg-white border border-gray-200 text-gray-600 hover:text-red-600 hover:border-red-200 hover:bg-red-50 rounded-full transition-all shadow-sm hover:shadow-md"
                title={product && isInWishlist(product.id) ? "Remove from Wishlist" : "Add to Wishlist"}
              >
                <Heart size={18} className={product && isInWishlist(product.id) ? "text-red-500 fill-red-500" : ""} />
              </button>
            </div>
            <h1 className="text-xl md:text-2xl font-medium text-gray-900 leading-tight mb-2 pr-24 break-words">
              {product.title}
            </h1>
            <a href="#" className="text-[#007185] text-sm hover:text-[#c45500] hover:underline">Visit the Store</a>
            
            <div className="flex items-center gap-2 mt-2 mb-4">
              <div className="flex text-[#ffa41c]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} className={i < Math.floor(product.rating) ? "" : "text-gray-300"} />
                ))}
              </div>
              <span className="text-[#007185] text-sm hover:text-[#c45500] hover:underline cursor-pointer">
                {product.reviews.toLocaleString()} ratings
              </span>
              <span className="text-gray-400">|</span>
              <span className="text-[#007185] text-sm hover:text-[#c45500] hover:underline cursor-pointer">
                Search this page
              </span>
            </div>

            <hr className="border-gray-200 mb-4" />

            <div className="flex items-baseline gap-1 mb-1">
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-sm font-medium text-[#cc0c39]">
                  -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
                </span>
              )}
              <div className="flex items-start">
                <span className="text-sm mt-1">₹</span>
                <span className="text-3xl font-medium">{Math.floor(product.price || 0)}</span>
                <span className="text-sm mt-1">{((product.price || 0) % 1).toFixed(2).substring(1)}</span>
              </div>
            </div>
            {product.originalPrice && product.originalPrice > product.price && (
              <div className="text-sm text-gray-500 mb-4">
                M.R.P.: <span className="line-through">₹{product.originalPrice.toFixed(2)}</span>
              </div>
            )}

            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="flex flex-col items-center text-center gap-1">
                <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-[#007185]">
                  <RotateCcw size={20} />
                </div>
                <span className="text-[10px] font-medium text-[#007185]">30-day returns</span>
              </div>
              <div className="flex flex-col items-center text-center gap-1">
                <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-[#007185]">
                  <Truck size={20} />
                </div>
                <span className="text-[10px] font-medium text-[#007185]">{brandName} Delivered</span>
              </div>
              <div className="flex flex-col items-center text-center gap-1">
                <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-[#007185]">
                  <ShieldCheck size={20} />
                </div>
                <span className="text-[10px] font-medium text-[#007185]">Secure transaction</span>
              </div>
              <div className="flex flex-col items-center text-center gap-1">
                <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-[#007185]">
                  <Info size={20} />
                </div>
                <span className="text-[10px] font-medium text-[#007185]">Top Brand</span>
              </div>
            </div>

            <hr className="border-gray-200 mb-6" />

            <div className="space-y-4">
              <h3 className="font-bold text-sm">About this item</h3>
              <ul className="list-disc list-inside text-sm space-y-2 text-gray-800">
                <li>High-performance features designed for everyday use and professional tasks.</li>
                <li>Sleek, modern design that fits perfectly into any workspace or home environment.</li>
                <li>Built with durable materials to ensure long-lasting reliability and performance.</li>
                <li>Includes a comprehensive warranty and access to our world-class customer support.</li>
                <li>Energy-efficient technology that helps reduce your environmental footprint.</li>
              </ul>
            </div>

            <hr className="border-gray-200 my-6" />

            {/* Reviews Section */}
            <div className="space-y-4">
              <h3 className="font-bold text-lg">Customer Reviews</h3>
              <div className="space-y-4">
                {reviews.length === 0 ? (
                  <p className="text-sm text-gray-500 italic">No reviews yet. Be the first to review!</p>
                ) : (
                  <>
                    {reviews.slice(0, showAllReviews ? reviews.length : 3).map(review => (
                      <div key={review.id} className="border-b pb-4">
                        <div className="flex justify-between items-start mb-1">
                          <div className="flex items-center gap-2">
                            <img 
                              src={review.userPhoto || `https://ui-avatars.com/api/?name=${encodeURIComponent(review.userName)}&background=random`} 
                              alt={review.userName} 
                              className="w-8 h-8 rounded-full object-cover" 
                              referrerPolicy="no-referrer" 
                            />
                            <span className="font-medium text-sm">{review.userName}</span>
                            {review.isAdminReview && (
                              <span className="bg-gray-100 text-gray-600 text-[10px] px-1.5 py-0.5 rounded font-bold uppercase">Verified Purchase</span>
                            )}
                          </div>
                          {user?.role === 'admin' && (
                            <button 
                              onClick={() => handleDeleteReview(review.id)}
                              className="text-red-500 hover:text-red-700 p-1"
                              title="Delete Review"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mb-1">
                          <div className="flex text-[#ffa41c]">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} size={14} fill={i < review.rating ? "currentColor" : "none"} className={i < review.rating ? "" : "text-gray-300"} />
                            ))}
                          </div>
                          <span className="text-xs text-gray-500">
                            {review.createdAt?.toDate ? review.createdAt.toDate().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : (review.date || 'Recently')}
                          </span>
                        </div>
                        <p className="text-sm text-gray-700">{review.text || review.comment}</p>
                        {review.image && (
                          <img src={review.image} alt="Review" className="mt-2 w-32 h-32 object-cover rounded" referrerPolicy="no-referrer" />
                        )}
                      </div>
                    ))}
                    {reviews.length > 3 && (
                      <button 
                        onClick={() => setShowAllReviews(!showAllReviews)}
                        className="text-sm text-blue-600 font-medium hover:underline"
                      >
                        {showAllReviews ? 'Show Less' : 'Show More'}
                      </button>
                    )}
                  </>
                )}
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-bold text-sm mb-2">Add a Review</h4>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm">Rating:</span>
                  <select value={newReview.rating} onChange={e => setNewReview({...newReview, rating: Number(e.target.value)})} className="border rounded p-1 text-sm">
                    {[1, 2, 3, 4, 5].map(r => <option key={r} value={r}>{r} Stars</option>)}
                  </select>
                </div>
                <textarea 
                  value={newReview.text} 
                  onChange={e => setNewReview({...newReview, text: e.target.value})}
                  className="w-full border rounded p-2 text-sm mb-2"
                  placeholder="Write your review here..."
                  rows={3}
                />
                <div className="mb-2">
                  <input type="file" accept="image/*" onChange={handleImageChange} className="text-sm" />
                  {newReview.image && <img src={newReview.image} alt="Preview" className="mt-2 w-20 h-20 object-cover rounded" />}
                </div>
                <button onClick={handleAddReview} className="bg-primary text-black px-4 py-2 rounded text-sm font-bold hover:opacity-90 transition-opacity">Submit Review</button>
              </div>
            </div>
          </div>

          {/* Buy Column */}
          <div className="md:col-span-12 lg:col-span-3">
            <div className="border border-gray-300 rounded-lg p-4 sticky top-4">
              <div className="flex items-start mb-2">
                <span className="text-sm mt-1">₹</span>
                <span className="text-2xl font-medium">{Math.floor(product.price || 0)}</span>
                <span className="text-sm mt-1">{((product.price || 0) % 1).toFixed(2).substring(1)}</span>
              </div>
              
              <div className="text-sm mb-4">
                <span className="text-[#007600] font-medium">In Stock</span>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-600">Ships from</span>
                  <span className="text-gray-900">{brandName}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-600">Sold by</span>
                  <span className="text-gray-900">{brandName}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-600">Returns</span>
                  <span className="text-[#007185]">Eligible for Return, Refund or Replacement within 30 days of receipt</span>
                </div>
              </div>

              <div className="space-y-2">
                <button 
                  onClick={handleAddToCart}
                  className="w-full bg-primary hover:opacity-90 py-2 rounded-full text-sm font-bold shadow-sm transition-opacity flex items-center justify-center gap-2 text-black"
                >
                  <ShoppingCart size={18} />
                  Add to Cart
                </button>
                <button 
                  onClick={handleCheckout}
                  className="w-full bg-secondary hover:opacity-90 py-2 rounded-full text-sm font-bold shadow-sm transition-opacity text-white"
                >
                  Buy Now
                </button>
              </div>

              <div className="mt-4 flex items-center gap-2 text-xs text-[#007185] hover:text-[#c45500] hover:underline cursor-pointer">
                <ShieldCheck size={14} />
                Secure transaction
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
