import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import Header from '../components/Header';
import ProductCard from '../components/ProductCard';
import PaymentModal from '../components/PaymentModal';
import AddressModal from '../components/AddressModal';
import { useCart } from '../context/CartContext';
import { socket } from '../socket';
import { Product, Category } from '../types';
import { ArrowLeft } from 'lucide-react';

export default function CategoryProducts() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart, cartCount, cartTotal, placeOrder } = useCart();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState<any>(null);

  useEffect(() => {
    socket.on('initial_data', (data) => {
      setProducts(data.products);
      setCategories(data.categories || []);
    });
    socket.on('products_update', (updatedProducts) => {
      setProducts(updatedProducts);
    });
    socket.on('categories_update', (updatedCategories) => {
      setCategories(updatedCategories);
    });

    if (socket.connected) {
      socket.disconnect();
      socket.connect();
    }

    return () => {
      socket.off('initial_data');
      socket.off('products_update');
      socket.off('categories_update');
    };
  }, []);

  const category = categories.find(c => c.id === id);
  const filteredProducts = products.filter(p => p.categoryId === id);

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    toast.success('Added to cart!');
  };

  const handleCheckout = () => {
    if (cartCount === 0) return toast.error('Cart is empty');
    setIsAddressModalOpen(true);
  };

  const handleAddressConfirm = (address: any) => {
    setDeliveryAddress(address);
    setIsAddressModalOpen(false);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentConfirm = (method: string) => {
    socket.emit('place_order', {
      total: cartTotal,
      address: deliveryAddress,
      paymentMethod: method
    });
    
    placeOrder(deliveryAddress, method);
    
    setIsPaymentModalOpen(false);
    toast.success(`Order placed successfully! Delivering to ${deliveryAddress.fullName}`);
    navigate('/orders');
  };

  return (
    <div className="min-h-screen bg-[#eaeded] font-sans">
      <Header 
        cartCount={cartCount} 
        cartTotal={cartTotal} 
        onCheckout={handleCheckout} 
      />

      <AddressModal 
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        onConfirm={handleAddressConfirm}
      />

      <PaymentModal 
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onConfirm={handlePaymentConfirm}
        totalAmount={cartTotal}
        deliveryAddress={deliveryAddress}
      />
      
      <main className="max-w-[1500px] mx-auto pb-10">
        <div className="bg-white p-4 flex items-center gap-4 border-b border-gray-200">
          <button onClick={() => navigate(-1)} className="p-1 hover:bg-gray-100 rounded-full">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold">{category?.name || 'Category'}</h1>
        </div>

        <div className="px-4 md:px-6 mt-6">
          {filteredProducts.length === 0 ? (
            <div className="bg-white p-10 rounded-lg text-center shadow-sm">
              <p className="text-gray-500 text-lg">No products found in this category.</p>
              <button 
                onClick={() => navigate('/')}
                className="mt-4 text-blue-600 hover:underline font-medium"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
              {filteredProducts.map(product => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onAddToCart={() => handleAddToCart(product)} 
                />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
