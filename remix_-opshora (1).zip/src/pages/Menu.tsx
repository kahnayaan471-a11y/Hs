import React, { useState, useEffect } from 'react';
import { socket } from '../socket';
import { Camera, Mic, ScanLine, ShoppingBag, CreditCard, Box, RotateCcw, User, List, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Category } from '../types';
import { useTheme } from '../hooks/useTheme';

import { useAuth } from '../context/AuthContext';

export default function Menu() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [sliders, setSliders] = useState<any[]>([]);
  const [currentSliderIndex, setCurrentSliderIndex] = useState(0);
  const { brandName } = useTheme();
  const { user } = useAuth();

  useEffect(() => {
    socket.on('initial_data', (data) => {
      setCategories(data.categories || []);
      setSliders(data.sliders || []);
    });
    socket.on('categories_update', (newCategories) => {
      setCategories(newCategories);
    });
    socket.on('sliders_update', (newSliders) => {
      setSliders(newSliders);
    });

    if (socket.connected) {
      socket.disconnect();
      socket.connect();
    }

    return () => {
      socket.off('initial_data');
      socket.off('categories_update');
      socket.off('sliders_update');
    };
  }, []);

  useEffect(() => {
    if (sliders.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSliderIndex((prev) => (prev + 1) % sliders.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [sliders]);

  return (
    <div 
      className="min-h-screen pb-20 font-sans bg-gray-50"
    >
      {/* Background Slider for Menu section */}
      <div className="relative h-40 w-full overflow-hidden">
        {sliders.length > 0 ? (
          sliders.map((slider, index) => (
            <div 
              key={slider.id} 
              className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSliderIndex ? 'opacity-100' : 'opacity-0'}`}
            >
              <img 
                src={slider.image} 
                alt={`Slider ${index + 1}`} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50"></div>
            </div>
          ))
        ) : (
          <div className="absolute inset-0 bg-gradient-to-b from-[#84d8e3] to-gray-50"></div>
        )}
        
        <div className="relative z-10 p-4">
          <h1 className="text-xl font-bold text-gray-900 text-center w-full">{brandName}</h1>
        </div>
      </div>

      <div className="p-4 space-y-6 -mt-10 relative z-20">
        {/* Top Categories Section */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-sm text-gray-800">Top Categories For You</h2>
            <div className="h-[1px] flex-1 bg-gray-300 ml-4"></div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {/* Static "Top Picks" like in the image */}
            <div className="flex flex-col items-center gap-2">
              <div className="w-16 h-16 bg-white rounded-lg shadow-sm flex items-center justify-center p-2">
                <img src="https://img.icons8.com/fluency/48/sparkling.png" alt="Top Picks" className="w-10 h-10" />
              </div>
              <span className="text-[10px] font-bold text-center">Top Picks</span>
            </div>

            {/* Dynamic Categories from Admin */}
            {categories.map((cat) => (
              <Link key={cat.id} to={`/category/${cat.id}`} className="flex flex-col items-center gap-2">
                <div className="w-16 h-16 bg-white rounded-lg shadow-sm flex items-center justify-center p-2 overflow-hidden">
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                </div>
                <span className="text-[10px] font-medium text-center line-clamp-1">{cat.name}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Quick Links Grid */}
        <div className="grid grid-cols-2 gap-3 mt-8">
          <Link to="/orders" className="bg-white p-4 rounded-xl shadow-sm flex items-center justify-center gap-2 border border-gray-100">
            <Box size={18} className="text-gray-400" />
            <span className="text-sm font-medium">Orders</span>
          </Link>
          <Link to="/buy-again" className="bg-white p-4 rounded-xl shadow-sm flex items-center justify-center gap-2 border border-gray-100">
            <RotateCcw size={18} className="text-gray-400" />
            <span className="text-sm font-medium">Buy Again</span>
          </Link>
          <Link to="/account" className="bg-white p-4 rounded-xl shadow-sm flex items-center justify-center gap-2 border border-gray-100">
            <User size={18} className="text-gray-400" />
            <span className="text-sm font-medium">Account</span>
          </Link>
          <Link to="/wishlist" className="bg-white p-4 rounded-xl shadow-sm flex items-center justify-center gap-2 border border-gray-100">
            <Heart size={18} className="text-gray-400" />
            <span className="text-sm font-medium">Wishlist</span>
          </Link>
          {user?.role === 'admin' && (
            <Link to="/admin" className="bg-red-50 bg-opacity-50 p-4 rounded-xl shadow-sm flex items-center justify-center gap-2 border border-red-100">
              <ScanLine size={18} className="text-red-400" />
              <span className="text-sm font-bold text-red-600">Admin Panel</span>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
