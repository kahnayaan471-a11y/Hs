import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Settings, Bell, ChevronRight, Package, RefreshCw, User, List, Search, Camera, Mic, QrCode, MapPin, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../hooks/useTheme';
import { socket } from '../socket';
import AddressModal from '../components/AddressModal';

export default function Account() {
  const { cartCount, cartTotal, orders } = useCart();
  const { user, isLoggedIn, logout, login, resellerUser, isResellerLoggedIn, resellerLogin, resellerLogout } = useAuth();
  const navigate = useNavigate();
  
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isResellerModalOpen, setIsResellerModalOpen] = useState(false);
  const [resellerEmailInput, setResellerEmailInput] = useState('');
  const [resellerPasswordInput, setResellerPasswordInput] = useState('');
  const [sliders, setSliders] = useState<any[]>([]);
  const [currentSliderIndex, setCurrentSliderIndex] = useState(0);

  const handleAddressConfirm = (address: any) => {
    localStorage.setItem('deliveryAddress', JSON.stringify(address));
    setIsAddressModalOpen(false);
    toast.success('Address updated successfully!');
  };

  const handleResellerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resellerEmailInput || !resellerPasswordInput) return;
    
    socket.emit('verify_reseller', { email: resellerEmailInput, password: resellerPasswordInput }, (res: any) => {
      if (res.success) {
        toast.success('Access granted! You can now access reselling features.');
        resellerLogin(resellerEmailInput);
        setIsResellerModalOpen(false);
        setResellerEmailInput('');
        setResellerPasswordInput('');
      } else {
        toast.error(res.message || 'Invalid email or password.');
      }
    });
  };

  useEffect(() => {
    socket.on('initial_data', (data) => {
      setSliders(data.sliders || []);
    });
    socket.on('sliders_update', (updatedSliders) => {
      setSliders(updatedSliders);
    });

    if (socket.connected) {
      socket.disconnect();
      socket.connect();
    }

    return () => {
      socket.off('initial_data');
      socket.off('sliders_update');
    };
  }, []);

  useEffect(() => {
    if (sliders.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentSliderIndex((prev) => (prev + 1) % sliders.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [sliders]);
  
  const quickActions = [
    { label: 'Orders', icon: Package, path: '/orders' },
    { label: 'Buy Again', icon: RefreshCw, path: '/orders' },
    { label: 'Resell', icon: ShoppingBag, path: '/account' },
    { label: 'Account', icon: User, path: '/account' },
    { label: 'Lists', icon: List, path: '/account' },
  ];

  const keepShopping = [
    { title: 'Screen protect...', image: 'https://picsum.photos/seed/screen/200/200', viewed: '1 viewed' },
    { title: 'Mobile cases & ...', image: 'https://picsum.photos/seed/case/200/200', viewed: '5 viewed' },
    { title: "Men's pants", image: 'https://picsum.photos/seed/pants/200/200', viewed: '1 viewed' },
    { title: 'Smart bulb', image: 'https://picsum.photos/seed/bulb/200/200', viewed: '2 viewed' },
    { title: 'Air duster', image: 'https://picsum.photos/seed/duster/200/200', viewed: '3 viewed' },
  ];

  return (
    <div 
      className="min-h-screen font-sans pb-20 bg-white"
    >
      <AddressModal 
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
        onConfirm={handleAddressConfirm}
      />

      {/* Background Slider for "You" section */}
      <div className="relative h-48 w-full overflow-hidden">
        {sliders.length > 0 ? (
          sliders.map((slider, index) => (
            <div 
              key={slider.id} 
              className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSliderIndex ? 'opacity-100' : 'opacity-0'}`}
            >
              <img 
                src={slider.image} 
                alt={`Slider ${index + 1}`} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white"></div>
            </div>
          ))
        ) : (
          <div className="absolute inset-0 bg-gradient-to-b from-[#84d8e3] to-white"></div>
        )}
        
        <div className="relative z-10 px-4 pt-6">
          {/* User Greeting */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-sm">
                <User size={24} className="text-gray-500" />
              </div>
              <div className="flex items-center gap-1">
                <span className="text-xl">Hello, <span className="font-bold">{isLoggedIn ? user?.name : 'Sign in'}</span></span>
                <ChevronRight size={20} className="text-gray-400" />
              </div>
            </div>
            <div className="flex items-center gap-4 text-gray-700">
              <Settings size={24} />
              <div className="relative">
                <Bell size={24} />
                <span className="absolute -top-1 -right-1 bg-red-600 w-2 h-2 rounded-full"></span>
              </div>
              <div className="flex items-center gap-1">
                <img src="https://flagcdn.com/w20/in.png" alt="India" className="w-5" />
                <span className="text-sm font-bold">EN</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-12 relative z-20">
        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3 mb-8">
          {quickActions.map((action) => (
            <button 
              key={action.label}
              onClick={() => navigate(action.path)}
              className="border border-gray-300 rounded-full py-2.5 px-4 text-sm font-medium hover:bg-gray-50 transition-colors"
            >
              {action.label}
            </button>
          ))}
          <button 
            onClick={() => setIsAddressModalOpen(true)}
            className="border border-gray-300 rounded-full py-2.5 px-4 text-sm font-medium hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
          >
            <MapPin size={16} />
            Edit Address
          </button>
        </div>

        {/* Your Orders */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Your Orders</h2>
            <button 
              onClick={() => navigate('/orders')}
              className="text-blue-600 text-sm"
            >
              See all
            </button>
          </div>
          
          {orders.length === 0 ? (
            <>
              <p className="text-gray-600 mb-4">Hi! You have no recent orders.</p>
              <button 
                onClick={() => navigate('/')}
                className="w-full border border-gray-300 rounded-lg py-3 text-sm font-medium hover:bg-gray-50 transition-colors"
              >
                Return to the Homepage
              </button>
            </>
          ) : (
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
              {orders.slice(0, 5).map((order) => (
                <div 
                  key={order.id} 
                  onClick={() => navigate('/orders')}
                  className="flex-shrink-0 w-32 border border-gray-200 rounded-lg p-2 cursor-pointer hover:bg-gray-50"
                >
                  <div className="aspect-square flex items-center justify-center mb-2">
                    <img 
                      src={order.items[0]?.image} 
                      alt={order.items[0]?.title} 
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                  <p className="text-[10px] font-bold text-green-700">{order.status}</p>
                  <p className="text-[10px] text-gray-500 truncate">{new Date(order.date).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Buy Again */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-bold">Buy Again</h2>
            <ChevronRight size={24} />
          </div>
          <p className="text-sm text-gray-600 mb-4">See what others are reordering on Buy Again</p>
          <button className="w-full border border-gray-300 rounded-lg py-3 text-sm font-medium hover:bg-gray-50 transition-colors">
            Visit Buy Again
          </button>
        </div>

        {/* Keep shopping for */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Keep shopping for</h2>
            <ChevronRight size={24} />
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
            {keepShopping.map((item, i) => (
              <div key={i} className="flex-shrink-0 w-32">
                <div className="border border-gray-200 rounded-lg p-2 mb-2 aspect-square flex items-center justify-center">
                  <img src={item.image} alt={item.title} className="max-h-full max-w-full object-contain" />
                </div>
                <p className="text-xs font-medium truncate">{item.title}</p>
                <p className="text-[10px] text-gray-500">{item.viewed}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Login/Logout Button */}
        {user?.role === 'admin' && (
          <button 
            onClick={() => navigate('/admin')}
            className="w-full bg-red-600 text-white rounded-lg py-3 text-sm font-bold shadow-sm hover:bg-red-700 transition-colors mb-4"
          >
            Go to Admin Panel
          </button>
        )}
        {!isLoggedIn ? (
          <button 
            onClick={async () => {
              try {
                await login();
                toast.success('Signed in successfully');
              } catch (error) {
                // Error handled in login function
              }
            }}
            className="w-full bg-[#ffd814] hover:bg-[#f7ca00] rounded-lg py-3 text-sm font-medium shadow-sm transition-colors mt-4"
          >
            Sign In
          </button>
        ) : (
          <button 
            onClick={async () => {
              await logout();
              toast.success('Signed out successfully');
              navigate('/');
            }}
            className="w-full border border-gray-300 rounded-lg py-3 text-sm font-medium text-red-600 hover:bg-red-50 transition-colors mt-4"
          >
            Sign Out
          </button>
        )}
      </div>

      {/* Reseller Password Modal */}
      {isResellerModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Reseller Access</h2>
            <p className="text-sm text-gray-600 mb-4">Please enter your reseller password to continue.</p>
            <form onSubmit={handleResellerSubmit}>
              <input
                type="email"
                value={resellerEmailInput}
                onChange={(e) => setResellerEmailInput(e.target.value)}
                placeholder="Enter email"
                className="w-full p-3 border rounded-lg mb-3"
                required
              />
              <input
                type="password"
                value={resellerPasswordInput}
                onChange={(e) => setResellerPasswordInput(e.target.value)}
                placeholder="Enter password"
                className="w-full p-3 border rounded-lg mb-4"
                required
              />
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsResellerModalOpen(false)}
                  className="flex-1 py-2 bg-gray-100 text-gray-800 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 text-white rounded-lg font-medium"
                >
                  Verify
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
