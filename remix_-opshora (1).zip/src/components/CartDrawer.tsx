import React from 'react';
import { X, ShoppingCart, Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useCart } from '../context/CartContext';
import { useTheme } from '../hooks/useTheme';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

export default function CartDrawer({ isOpen, onClose, onCheckout }: CartDrawerProps) {
  const { cartItems, removeFromCart, updateQuantity, cartTotal, cartCount } = useCart();
  const { brandName } = useTheme();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[110] flex justify-end"
      >
        <div 
          className="fixed inset-0 bg-black/50 transition-opacity" 
          onClick={onClose}
        ></div>
        
        <motion.div 
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          className="relative w-full max-w-md bg-[#f0f2f2] h-full shadow-2xl flex flex-col"
        >
          {/* Header */}
          <div className="bg-secondary text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingCart size={24} />
              <h2 className="font-bold text-lg">Shopping Cart ({cartCount})</h2>
            </div>
            <button onClick={onClose} className="p-1 hover:bg-white/10 rounded">
              <X size={24} />
            </button>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500 space-y-4">
                <ShoppingCart size={64} strokeWidth={1} />
                <p className="text-xl font-medium">Your cart is empty</p>
                <button 
                  onClick={onClose}
                  className="bg-primary hover:opacity-90 text-black px-6 py-2 rounded-lg font-bold shadow-sm transition-opacity"
                >
                  Continue Shopping
                </button>
              </div>
            ) : (
              cartItems.map((item) => (
                <div key={item.id} className="bg-white p-4 rounded-lg shadow-sm flex gap-4">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-20 h-20 object-contain shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-sm line-clamp-2 mb-1">{item.title}</h3>
                    <p className="text-[#B12704] font-bold text-lg">₹{(item.price || 0).toFixed(2)}</p>
                    
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border rounded-lg bg-gray-50">
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-gray-200 rounded-l-lg transition-colors"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="px-3 py-1 font-medium text-sm">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-gray-200 rounded-r-lg transition-colors"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                      
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="text-gray-400 hover:text-red-600 p-1 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          {cartItems.length > 0 && (
            <div className="bg-white p-6 border-t shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-600">Subtotal ({cartCount} items):</span>
                <span className="text-xl font-bold text-[#B12704]">₹{(cartTotal || 0).toFixed(2)}</span>
              </div>
              
              <button 
                onClick={onCheckout}
                className="w-full bg-primary hover:opacity-90 text-black py-3 rounded-lg font-bold shadow-sm transition-opacity flex items-center justify-center gap-2"
              >
                Proceed to Checkout
                <ArrowRight size={20} />
              </button>
              
              <p className="text-[11px] text-gray-500 text-center mt-3">
                By proceeding to checkout, you agree to {brandName}'s Conditions of Use and Privacy Notice.
              </p>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
