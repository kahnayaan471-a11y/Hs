import { Search, ShoppingCart, MapPin, Menu, X, UserCircle, Mic, Sun, Moon, MessageCircle } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { Link, useNavigate } from 'react-router-dom';
import AuthModal from './AuthModal';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../hooks/useTheme';
import { useThemeContext } from '../context/ThemeContext';

export default function Header({ 
  cartCount, 
  cartTotal, 
  onCheckout
}: { 
  cartCount: number, 
  cartTotal: number, 
  onCheckout: () => void
}) {
  const navigate = useNavigate();
  const { user, isLoggedIn, logout } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);
  const { brandName, brandImage } = useTheme();
  const { isDarkMode, toggleDarkMode } = useThemeContext();

  const handleNavClick = (item: string) => {
    toast.success(`Navigating to ${item}...`);
  };

  const handleAccountClick = () => {
    if (isLoggedIn) {
      setIsAccountDropdownOpen(!isAccountDropdownOpen);
    } else {
      setIsAuthModalOpen(true);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setIsAccountDropdownOpen(false);
      toast.success('Signed out successfully');
      navigate('/');
    } catch (error) {
      toast.error('Failed to sign out');
    }
  };

  // handleMicClick removed as it's no longer used without search bar

  return (
    <>
      <header className="w-full">
        {/* Main Header */}
        <div className="bg-primary text-black flex items-center px-2 md:px-4 py-2 gap-2 md:gap-4 text-sm">
          {/* Logo (Removed left logo to avoid redundancy with centered brand name) */}
          <div className="flex items-center p-1 md:p-2 shrink-0">
            {/* Logo removed as requested */}
          </div>

          {/* Location */}
          <div className="hidden md:flex items-center border border-transparent hover:border-white p-1 rounded cursor-pointer">
            <MapPin size={18} className="mt-2" />
            <div className="flex flex-col ml-1">
              <span className="text-xs text-gray-700 leading-3">Deliver to</span>
              <span className="font-bold leading-4">India</span>
            </div>
          </div>

          {/* Brand Name (Centered) */}
          <div className="flex-1 flex justify-center items-center gap-2">
            {brandImage ? (
              <img src={brandImage} alt={brandName} className="h-8 md:h-10 object-contain" referrerPolicy="no-referrer" />
            ) : (
              <span className="text-lg md:text-2xl font-bold tracking-widest uppercase text-black font-brand">{brandName}</span>
            )}
          </div>

          {/* Dark Mode Toggle */}
          <button 
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-black/10 transition-colors"
            aria-label="Toggle Dark Mode"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>

          {/* Account */}
          <div className="relative">
            <div 
              onClick={handleAccountClick}
              className="hidden lg:flex flex-col border border-transparent hover:border-white p-1 rounded cursor-pointer"
            >
              <span className="text-xs leading-3">Hello, {isLoggedIn ? user?.name : 'sign in'}</span>
              <span className="font-bold leading-4">Account & Lists</span>
            </div>

            {/* Account Dropdown */}
            {isAccountDropdownOpen && isLoggedIn && (
              <div className="absolute top-full right-0 mt-2 w-64 bg-white rounded-md shadow-lg py-2 z-50 border border-gray-200 text-black">
                <div className="px-4 py-2 border-b border-gray-100">
                  <p className="text-sm font-bold">Your Account</p>
                </div>
                <Link 
                  to="/account" 
                  className="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-blue-600"
                  onClick={() => setIsAccountDropdownOpen(false)}
                >
                  Account Settings
                </Link>
                <Link 
                  to="/orders" 
                  className="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-blue-600"
                  onClick={() => setIsAccountDropdownOpen(false)}
                >
                  Your Orders
                </Link>
                <Link 
                  to="/wishlist" 
                  className="block px-4 py-2 text-sm hover:bg-gray-100 hover:text-blue-600"
                  onClick={() => setIsAccountDropdownOpen(false)}
                >
                  Wishlist
                </Link>
                <div className="border-t border-gray-100 mt-2 pt-2">
                  <button 
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-sm hover:bg-gray-100 hover:text-blue-600"
                  >
                    Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Orders */}
          <Link to="/orders" className="hidden lg:flex flex-col border border-transparent hover:border-white p-1 rounded cursor-pointer">
            <span className="text-xs leading-3">Returns</span>
            <span className="font-bold leading-4">& Orders</span>
          </Link>

          {/* Cart */}
          <Link to="/cart" className="flex items-center border border-transparent hover:border-white p-1 rounded cursor-pointer relative shrink-0">
            <div className="relative flex items-center">
              <ShoppingCart size={32} />
              <span className="absolute top-0 left-1/2 -translate-x-1/2 -mt-1 text-[#f08804] font-bold text-sm">
                {cartCount}
              </span>
            </div>
            <div className="flex flex-col ml-1">
              <span className="font-bold mt-3 hidden md:inline leading-3">Cart</span>
              {cartTotal > 0 && <span className="text-[11px] text-[#f08804] hidden md:inline font-bold">₹{(cartTotal || 0).toFixed(2)}</span>}
            </div>
          </Link>
        </div>

        {/* Sub Header */}
        <div className="bg-secondary text-white flex items-center px-4 py-1 gap-4 text-sm whitespace-nowrap overflow-x-auto no-scrollbar">
          <div 
            onClick={() => setIsSidebarOpen(true)}
            className="flex items-center gap-1 border border-transparent hover:border-white p-1 rounded cursor-pointer font-bold shrink-0"
          >
            <Menu size={20} />
            All
          </div>
          <Link 
            to="/orders"
            className="border border-transparent hover:border-white p-1 rounded cursor-pointer shrink-0 font-bold"
          >
            Your Orders
          </Link>
          <Link 
            to="/reselling-wallet"
            className="border border-transparent hover:border-white p-1 rounded cursor-pointer shrink-0 font-bold text-blue-200"
          >
            Reselling
          </Link>
          {['Today\'s Deals', 'Customer Service'].map(item => (
            <span 
              key={item} 
              onClick={() => handleNavClick(item)}
              className="border border-transparent hover:border-white p-1 rounded cursor-pointer shrink-0"
            >
              {item}
            </span>
          ))}
        </div>
      </header>

      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div 
            className="fixed inset-0 bg-black/80 transition-opacity" 
            onClick={() => setIsSidebarOpen(false)}
          ></div>
          
          {/* Sidebar Content */}
          <div 
            className="relative w-[365px] max-w-[80%] h-full bg-white shadow-xl flex flex-col overflow-y-auto animate-in slide-in-from-left duration-300"
          >
            {/* Sidebar Header */}
            <div 
              onClick={() => { 
                if (!isLoggedIn) {
                  setIsSidebarOpen(false); 
                  setIsAuthModalOpen(true); 
                }
              }}
              className="bg-secondary text-white p-4 flex items-center gap-3 cursor-pointer hover:opacity-90 transition-opacity"
            >
              <UserCircle size={30} />
              <span className="font-bold text-lg tracking-wide">Hello, {isLoggedIn ? user?.name : 'sign in'}</span>
            </div>
            
            {/* Sidebar Links */}
            <div className="py-2 text-gray-800">
              <div className="px-8 py-3 font-bold text-lg">Trending</div>
              <div className="px-8 py-3 hover:bg-gray-100 cursor-pointer" onClick={() => { navigate('/orders'); setIsSidebarOpen(false); }}>Your Orders</div>
              <div className="px-8 py-3 hover:bg-gray-100 cursor-pointer text-blue-600 font-bold" onClick={() => { navigate('/reselling-wallet'); setIsSidebarOpen(false); }}>Reselling Wallet</div>
              <div className="px-8 py-3 hover:bg-gray-100 cursor-pointer" onClick={() => { handleNavClick('Best Sellers'); setIsSidebarOpen(false); }}>Best Sellers</div>
              <div className="px-8 py-3 hover:bg-gray-100 cursor-pointer" onClick={() => { handleNavClick('New Releases'); setIsSidebarOpen(false); }}>New Releases</div>
              <div className="px-8 py-3 hover:bg-gray-100 cursor-pointer" onClick={() => { handleNavClick('Movers & Shakers'); setIsSidebarOpen(false); }}>Movers & Shakers</div>
              
              {(user?.role === 'admin' || user?.role === 'account_manager') && (
                <a
                  href="https://t.me/faaaaaaaaaaaaaaj"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-4 flex items-center gap-3 text-blue-600 font-bold hover:bg-blue-50 transition-colors"
                >
                  <MessageCircle size={24} />
                  We can make all types of websites and apps
                </a>
              )}
            </div>
          </div>

          {/* Close Button */}
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="relative p-4 text-white hover:text-gray-300 self-start"
          >
            <X size={32} />
          </button>
        </div>
      )}

      {/* Auth Modal */}
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
      />
    </>
  );
}
