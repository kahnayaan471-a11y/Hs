import React from 'react';
import { motion, Variants } from 'motion/react';
import { useTheme } from '../hooks/useTheme';

export default function SplashScreen({ onComplete }: { onComplete: () => void }) {
  const { brandName } = useTheme();
  const parts = brandName.split(' ');
  const part1 = parts[0] || "Opshora";
  const part2 = parts.slice(1).join(' ');

  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  const topVariants: Variants = {
    hidden: { y: -300, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1, 
      scale: [1, 1.05, 1],
      transition: { 
        y: { type: 'spring', damping: 15, stiffness: 100 },
        scale: { duration: 2, repeat: Infinity, ease: "easeInOut", delay: 1 }
      }
    },
  };

  const bottomVariants: Variants = {
    hidden: { y: 300, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1, 
      scale: [1, 1.05, 1],
      transition: { 
        y: { type: 'spring', damping: 15, stiffness: 100 },
        scale: { duration: 2, repeat: Infinity, ease: "easeInOut", delay: 1 }
      }
    },
  };

  return (
    <motion.div
      className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-teal-50 to-white z-50"
      initial={{ opacity: 1 }}
      animate={{ opacity: 0 }}
      transition={{ delay: 3.5, duration: 0.8 }}
      onAnimationComplete={onComplete}
    >
      <motion.div 
        className="flex flex-col items-center gap-4"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <motion.h1
          variants={topVariants}
          className="text-5xl md:text-8xl font-extrabold text-teal-900 drop-shadow-md font-brand"
        >
          {part1}
        </motion.h1>
        {part2 && (
          <motion.h1
            variants={bottomVariants}
            className="text-5xl md:text-8xl font-extrabold text-teal-600 drop-shadow-md font-brand"
          >
            {part2}
          </motion.h1>
        )}
      </motion.div>
    </motion.div>
  );
}
