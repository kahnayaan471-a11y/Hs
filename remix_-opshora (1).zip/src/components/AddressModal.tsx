import React, { useState } from 'react';
import { X, MapPin, Home, Building, Phone, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AddressModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (address: any) => void;
}

export default function AddressModal({ isOpen, onClose, onConfirm }: AddressModalProps) {
  const [address, setAddress] = useState(() => {
    const savedAddress = localStorage.getItem('deliveryAddress');
    return savedAddress ? JSON.parse(savedAddress) : {
      fullName: '',
      phone: '',
      houseNo: '',
      area: '',
      landmark: '',
      pincode: '',
      city: '',
      state: '',
      type: 'home'
    };
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.fullName || !address.phone || !address.houseNo || !address.area || !address.pincode) {
      return;
    }
    onConfirm(address);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[120] flex items-center justify-center p-4"
      >
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
        
        <motion.div 
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="relative bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-secondary text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin size={24} className="text-primary" />
              <h2 className="font-bold text-lg">Delivery Address</h2>
            </div>
            <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full transition-colors">
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input 
                    required
                    type="text" 
                    placeholder="Enter full name"
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                    value={address.fullName}
                    onChange={(e) => setAddress({...address, fullName: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Mobile Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input 
                    required
                    type="tel" 
                    placeholder="10-digit mobile number"
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                    value={address.phone}
                    onChange={(e) => setAddress({...address, phone: e.target.value})}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Flat, House no., Building, Company, Apartment</label>
              <input 
                required
                type="text" 
                placeholder="Enter details"
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                value={address.houseNo}
                onChange={(e) => setAddress({...address, houseNo: e.target.value})}
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Area, Street, Sector, Village</label>
              <input 
                required
                type="text" 
                placeholder="Enter area details"
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                value={address.area}
                onChange={(e) => setAddress({...address, area: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Pincode</label>
                <input 
                  required
                  type="text" 
                  placeholder="6 digits [0-9] PIN code"
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                  value={address.pincode}
                  onChange={(e) => setAddress({...address, pincode: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Town/City</label>
                <input 
                  required
                  type="text" 
                  placeholder="Enter city"
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                  value={address.city}
                  onChange={(e) => setAddress({...address, city: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Landmark (Optional)</label>
              <input 
                type="text" 
                placeholder="E.g. near Apollo Hospital"
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                value={address.landmark}
                onChange={(e) => setAddress({...address, landmark: e.target.value})}
              />
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-gray-700 uppercase tracking-wider">Address Type</label>
              <div className="flex gap-4">
                <button 
                  type="button"
                  onClick={() => setAddress({...address, type: 'home'})}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 transition-all ${
                    address.type === 'home' 
                    ? 'border-primary bg-primary/10 text-primary' 
                    : 'border-gray-100 bg-gray-50 text-gray-500'
                  }`}
                >
                  <Home size={18} />
                  <span className="font-bold text-sm">Home</span>
                </button>
                <button 
                  type="button"
                  onClick={() => setAddress({...address, type: 'work'})}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 transition-all ${
                    address.type === 'work' 
                    ? 'border-primary bg-primary/10 text-primary' 
                    : 'border-gray-100 bg-gray-50 text-gray-500'
                  }`}
                >
                  <Building size={18} />
                  <span className="font-bold text-sm">Work</span>
                </button>
              </div>
            </div>

            <div className="pt-4">
              <button 
                type="submit"
                className="w-full bg-primary hover:opacity-90 text-black py-4 rounded-xl font-bold shadow-lg shadow-primary/20 transition-all transform active:scale-[0.98]"
              >
                Use this address
              </button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
