import { Star, Check, Share, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import React from 'react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { useWishlist } from '../context/WishlistContext';

import { useTheme } from '../hooks/useTheme';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(product.id);

  const handleShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const shareData = {
      title: product.title,
      text: `Check out ${product.title} on Amazon!`,
      url: `${window.location.origin}/product/${product.id}`,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${window.location.origin}/product/${product.id}`);
        toast.success('Link copied to clipboard!');
      }
    } catch (err) {
      // User canceled or share failed silently
    }
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  return (
    <div 
      className="p-3 flex flex-col z-10 relative h-full overflow-hidden bg-white rounded-md shadow-sm hover:shadow-md transition-all duration-300 group border border-transparent hover:border-gray-200"
    >
      <div className="absolute top-2 right-2 flex flex-col gap-2 z-20 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-300">
        <button 
          onClick={handleShare}
          className="flex items-center justify-center w-8 h-8 bg-white/90 backdrop-blur-sm border border-gray-200 text-gray-600 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50 rounded-full shadow-sm hover:shadow-md transition-all focus-visible:ring-2 focus-visible:ring-blue-500 focus:outline-none"
          aria-label={`Share ${product.title}`}
        >
          <Share size={14} />
        </button>
        <button 
          onClick={handleWishlist}
          className="flex items-center justify-center w-8 h-8 bg-white/90 backdrop-blur-sm border border-gray-200 text-gray-600 hover:text-red-600 hover:border-red-300 hover:bg-red-50 rounded-full shadow-sm hover:shadow-md transition-all focus-visible:ring-2 focus-visible:ring-red-500 focus:outline-none"
          aria-label={inWishlist ? `Remove ${product.title} from wishlist` : `Add ${product.title} to wishlist`}
        >
          <Heart size={14} className={inWishlist ? "text-red-500 fill-red-500" : ""} />
        </button>
      </div>
      <Link to={`/product/${product.id}`} className="focus-visible:ring-2 focus-visible:ring-orange-500 focus:outline-none rounded-md block relative">
        {product.originalPrice && product.originalPrice > product.price && (
          <div className="absolute top-0 left-0 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-br-lg z-10 shadow-sm">
            {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
          </div>
        )}
        <div className="aspect-[4/5] w-full mb-3 flex items-center justify-center overflow-hidden bg-gray-50 rounded-md">
          <img src={product.image} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
        </div>
        <h2 className="text-[13px] leading-snug font-medium line-clamp-2 group-hover:text-orange-600 text-gray-900 break-words">{product.title}</h2>
      </Link>
      
      <div className="flex items-center mt-1 mb-0.5">
        <div className="flex text-[#ffa41c]">
          {[...Array(5)].map((_, i) => (
            <Star key={i} size={14} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} className={i < Math.floor(product.rating) ? "" : "text-gray-300"} />
          ))}
        </div>
        <Link to={`/product/${product.id}`} aria-label={`${product.reviews} reviews`} className="text-blue-600 text-[11px] ml-1.5 hover:underline focus-visible:ring-2 focus-visible:ring-orange-500 focus:outline-none rounded-sm">
          {product.reviews.toLocaleString()}
        </Link>
      </div>

      <div className="flex items-end mt-0.5 gap-1.5 flex-wrap">
        <div className="flex items-start">
          <span className="text-[10px] mt-1">₹</span>
          <span className="text-xl font-medium">{Math.floor(product.price)}</span>
          <span className="text-[10px] mt-1">{((product.price || 0) % 1).toFixed(2).substring(1)}</span>
        </div>
        {product.originalPrice && product.originalPrice > product.price && (
          <span className="text-xs text-gray-500 line-through mb-1">₹{product.originalPrice.toFixed(2)}</span>
        )}
      </div>

      <div className="mt-auto pt-3 flex flex-col gap-1.5">
        <button 
          onClick={() => onAddToCart(product)}
          aria-label={`Add ${product.title} to cart`}
          className="w-full bg-primary hover:opacity-90 text-black text-[13px] py-1.5 rounded-full shadow-sm transition-opacity focus-visible:ring-2 focus-visible:ring-orange-500 focus-visible:ring-offset-2 focus:outline-none whitespace-nowrap overflow-hidden text-ellipsis px-2 font-medium"
        >
          Add to cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
