import React, { useState, useEffect } from 'react';
import { X, ChevronRight, Plus, ChevronDown, CreditCard, Landmark, Banknote, Calculator, Wallet, ArrowLeft, Check, QrCode, Truck, Mail, Lock, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';
import { toast } from 'sonner';
import { socket } from '../socket';
import { useAuth } from '../context/AuthContext';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (method: string, details?: { utr?: string; isReselling?: boolean; profitMargin?: number; resellerEmail?: string; resellerPassword?: string; realPrice?: number }) => void;
  onEditAddress?: () => void;
  totalAmount: number;
  deliveryAddress?: any;
}

export default function PaymentModal({ isOpen, onClose, onConfirm, onEditAddress, totalAmount, deliveryAddress }: PaymentModalProps) {
  const { resellerUser, isResellerLoggedIn, resellerLogin } = useAuth();
  const [selectedMethod, setSelectedMethod] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success'>('idle');
  const [showQRCode, setShowQRCode] = useState(false);
  const [utr, setUtr] = useState('');
  const [timeLeft, setTimeLeft] = useState(300);
  const [isReselling, setIsReselling] = useState(false);
  const [profitMargin, setProfitMargin] = useState<string>('');
  const [resellerEmail, setResellerEmail] = useState(resellerUser?.email || '');
  const [resellerPassword, setResellerPassword] = useState('');
  const [isResellerVerified, setIsResellerVerified] = useState(isResellerLoggedIn);
  const [isVerifying, setIsVerifying] = useState(false);

  // Sync with auth context
  useEffect(() => {
    if (isResellerLoggedIn && resellerUser) {
      setResellerEmail(resellerUser.email);
      setIsResellerVerified(true);
    } else {
      setIsResellerVerified(false);
    }
  }, [isResellerLoggedIn, resellerUser]);

  // Reset timer when QR code is shown
  useEffect(() => {
    if (showQRCode) {
      setTimeLeft(300);
    }
  }, [showQRCode]);

  // Timer logic
  React.useEffect(() => {
    if (!showQRCode || timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          startProcessing();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [showQRCode, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const upiOptions = [
    { id: 'any_upi', name: 'Pay by any UPI App', subtitle: 'Google Pay, PhonePe, Paytm and more', icon: 'https://img.icons8.com/color/48/upi.png' },
  ];

  const moreWays = [];

  const upiId = '52440618ibraheem@fam';
  const currentTotal = totalAmount + (isReselling ? parseFloat(profitMargin) || 0 : 0);
  const upiUri = `upi://pay?pa=${upiId}&pn=Ibraheem&am=${(currentTotal || 0).toFixed(2)}&cu=INR`;

  const handleVerifyReseller = () => {
    if (!resellerEmail || !resellerPassword) {
      toast.error('Please enter both email and password');
      return;
    }

    setIsVerifying(true);
    socket.emit('verify_reseller', { email: resellerEmail, password: resellerPassword }, (res: any) => {
      setIsVerifying(false);
      if (res.success) {
        setIsResellerVerified(true);
        resellerLogin(resellerEmail);
        toast.success('Reseller verified successfully!');
      } else {
        toast.error(res.message || 'Invalid reseller credentials');
      }
    });
  };

  const handleContinue = () => {
    if (!selectedMethod) return;

    if (isReselling && !isResellerVerified) {
      toast.error('Please verify your reseller account first');
      return;
    }

    if (isReselling && (!profitMargin || parseFloat(profitMargin) <= 0)) {
      toast.error('Please enter a valid profit margin');
      return;
    }

    const isUPI = upiOptions.some(opt => opt.id === selectedMethod);
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    if (isUPI) {
      if (isMobile && selectedMethod !== 'any_upi') {
        window.location.href = upiUri;
      }
      setShowQRCode(true);
      return;
    }

    startProcessing();
  };

  const startProcessing = () => {
    setShowQRCode(false);
    setIsProcessing(true);
    setPaymentStatus('processing');

    // Simulate in-app payment processing with Opshora Pay
    setTimeout(() => {
      setPaymentStatus('success');
      setTimeout(() => {
        setIsProcessing(false);
        setPaymentStatus('idle');
        onConfirm(selectedMethod, { 
          utr,
          isReselling,
          profitMargin: isReselling ? parseFloat(profitMargin) || 0 : 0,
          resellerEmail: isReselling ? resellerEmail : '',
          resellerPassword: isReselling ? resellerPassword : '',
          realPrice: totalAmount
        });
        setUtr('');
        setIsReselling(false);
        setProfitMargin('');
      }, 1500);
    }, 2500);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex flex-col bg-white md:bg-black/50 md:items-center md:justify-center"
      >
        {showQRCode && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 z-[120] bg-black/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center"
          >
              <div className="bg-white p-8 shadow-lg border border-gray-100 flex flex-col items-center w-full h-full relative overflow-hidden">
              
              <div className="flex flex-col items-center mb-8">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                  <QrCode size={24} className="text-gray-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 tracking-wide">Checkout</h3>
                <p className="text-[10px] text-gray-500 uppercase tracking-[0.3em] font-bold mt-1">Secure Transaction</p>
              </div>
              
              <div className="relative">
                <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
                  <QRCodeSVG 
                    value={upiUri} 
                    size={200} 
                    level="H" 
                    includeMargin={false}
                    fgColor="#1a1a1a"
                  />
                </div>
              </div>

              <div className="mt-8 mb-8 text-center">
                <p className="text-[10px] text-gray-400 uppercase tracking-[0.4em] font-bold mb-1">Status</p>
                <p className="text-lg font-medium text-gray-800 tracking-widest uppercase">
                  Awaiting Payment
                </p>
                <div className="mt-2 bg-gray-100 border border-gray-200 rounded-full px-4 py-1 inline-block">
                  <p className="text-sm font-mono font-bold text-gray-700 tracking-widest">
                    {formatTime(timeLeft)}
                  </p>
                </div>
                <p className="text-[8px] text-gray-400 mt-2 max-w-[200px] mx-auto leading-relaxed">
                  After payment, please enter your 12-digit UTR number below for verification
                </p>
              </div>

              <div className="w-full space-y-4 mb-8">
                <div className="text-left">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 block ml-1">Transaction Reference (UTR)</label>
                  <input 
                    type="text" 
                    value={utr}
                    onChange={(e) => setUtr(e.target.value)}
                    placeholder="Enter 12-digit UTR number"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-4 text-sm text-gray-900 placeholder:text-gray-400 focus:border-gray-500 outline-none transition-all shadow-inner"
                  />
                </div>
              </div>

              <div className="w-full space-y-4">
                <button 
                  onClick={() => {
                    if (utr === '333') {
                      startProcessing();
                    } else {
                      window.location.href = upiUri;
                    }
                  }}
                  className="w-full py-4 rounded-xl font-bold tracking-widest uppercase text-xs bg-gray-900 text-white shadow-lg hover:bg-gray-800 transition-all flex items-center justify-center gap-2"
                >
                  <Landmark size={16} />
                  Pay via App
                </button>
                <button 
                  onClick={() => setShowQRCode(false)}
                  className="w-full text-gray-500 py-2 text-xs font-bold uppercase tracking-widest hover:text-gray-700 transition-colors"
                >
                  Cancel Order
                </button>
              </div>

              <div className="mt-10 pt-6 border-t border-gray-100 w-full flex items-center justify-center gap-6">
                <img src="https://img.icons8.com/color/48/upi.png" alt="UPI" className="w-5 h-5 grayscale opacity-30 hover:opacity-100 transition-opacity cursor-pointer" />
              </div>
            </div>
          </motion.div>
        )}

        {isProcessing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-[110] bg-white flex flex-col items-center justify-center p-6 text-center"
          >
            {paymentStatus === 'processing' ? (
              <>
                <div className="w-20 h-20 border-4 border-primary border-t-transparent rounded-full animate-spin mb-6"></div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2 font-brand">Opshora Pay</h3>
                <p className="text-gray-600">Processing...</p>
                <p className="text-sm text-gray-400 mt-8 italic">Please do not close this window or refresh the page</p>
              </>
            ) : (
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center"
              >
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <Check size={48} strokeWidth={3} />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2 font-brand">Payment Successful</h3>
                <p className="text-gray-600">Thank you for using Opshora Pay</p>
              </motion.div>
            )}
          </motion.div>
        )}

        <div className="flex items-center justify-between p-4 bg-[#f0f2f2] md:hidden">
          <button onClick={onClose}><ArrowLeft size={24} /></button>
          <span className="font-bold text-lg">Select a payment method</span>
          <button onClick={onClose} className="text-sm font-medium text-gray-600">CANCEL</button>
        </div>

        <motion.div 
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          className="flex-1 bg-white overflow-y-auto md:max-w-md md:rounded-lg md:shadow-2xl md:flex-none md:h-[90vh] w-full"
        >
          <div className="hidden md:flex items-center justify-between p-4 border-b">
            <h2 className="font-bold text-xl">Select a payment method</h2>
            <button onClick={onClose}><X size={24} /></button>
          </div>

          <div className="p-4 space-y-6">
            {/* Delivery Address Summary */}
            {deliveryAddress && (
              <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 flex items-start gap-3">
                <Landmark size={20} className="text-primary shrink-0 mt-1" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-bold text-primary uppercase tracking-wider">Delivering to</p>
                    {onEditAddress && (
                      <button 
                        onClick={onEditAddress}
                        className="text-xs font-bold text-primary hover:underline uppercase tracking-wider"
                      >
                        Edit
                      </button>
                    )}
                  </div>
                  <p className="text-sm font-bold text-gray-900">{deliveryAddress.fullName}</p>
                  <p className="text-xs text-gray-600 line-clamp-1">
                    {deliveryAddress.houseNo}, {deliveryAddress.area}, {deliveryAddress.city} - {deliveryAddress.pincode}
                  </p>
                </div>
              </div>
            )}

            {/* UPI Section */}
            <div className="border rounded-lg overflow-hidden">
              <div className="p-3 bg-gray-50 border-b">
                <span className="font-bold text-sm uppercase text-gray-600">UPI</span>
              </div>
              {upiOptions.map((option) => (
                <label 
                  key={option.id} 
                  className={`flex items-start gap-3 p-4 border-b last:border-b-0 cursor-pointer hover:bg-gray-50 transition-colors ${selectedMethod === option.id ? 'bg-primary/10' : ''}`}
                >
                  <input 
                    type="radio" 
                    name="payment" 
                    className="mt-1 w-5 h-5 accent-primary" 
                    checked={selectedMethod === option.id}
                    onChange={() => setSelectedMethod(option.id)}
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-bold text-gray-900">{option.name}</p>
                        {option.subtitle && <p className="text-xs text-gray-600">{option.subtitle}</p>}
                      </div>
                      <img src={option.icon} alt="" className="w-6 h-6 object-contain" />
                    </div>
                  </div>
                </label>
              ))}
              <label 
                className={`flex items-start gap-3 p-4 border-b last:border-b-0 cursor-pointer hover:bg-gray-50 transition-colors ${selectedMethod === 'cod' ? 'bg-primary/10' : ''}`}
                onClick={() => alert('Cash on Delivery is not available in your country')}
              >
                <input 
                  type="radio" 
                  name="payment" 
                  className="mt-1 w-5 h-5 accent-primary" 
                  checked={selectedMethod === 'cod'}
                  onChange={() => {}}
                />
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-gray-900">Cash on Delivery</p>
                      <p className="text-xs text-gray-600">Not available in your country</p>
                    </div>
                    <Truck className="w-6 h-6 text-gray-400" />
                  </div>
                </div>
              </label>
            </div>

            {/* Credit/Debit Cards */}
            <div>
              <p className="font-bold text-sm uppercase text-gray-600 mb-2">CREDIT & DEBIT CARDS</p>
              <button className="w-full flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="w-6 h-6 rounded-full border-2 border-blue-600 flex items-center justify-center text-blue-600 shrink-0">
                  <Plus size={16} strokeWidth={3} />
                </div>
                <span className="text-blue-600 font-medium text-left">Add a new credit or debit card</span>
              </button>
            </div>

            {/* Reselling Option */}
            <div className="border rounded-xl p-4 bg-gray-50 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calculator className="text-primary" size={20} />
                  <span className="font-bold text-gray-900">Reselling Option</span>
                </div>
                <div className="flex bg-white border rounded-lg overflow-hidden">
                  <button 
                    onClick={() => setIsReselling(true)}
                    className={`px-4 py-1 text-sm font-bold transition-colors ${isReselling ? 'bg-primary text-black' : 'text-gray-500 hover:bg-gray-50'}`}
                  >
                    Yes
                  </button>
                  <button 
                    onClick={() => {
                      setIsReselling(false);
                      setProfitMargin('');
                      setResellerEmail('');
                      setResellerPassword('');
                      setIsResellerVerified(false);
                    }}
                    className={`px-4 py-1 text-sm font-bold transition-colors ${!isReselling ? 'bg-gray-200 text-gray-700' : 'text-gray-500 hover:bg-gray-50'}`}
                  >
                    No
                  </button>
                </div>
              </div>

              {isReselling && (
                <div className="space-y-4 pt-2 border-t border-gray-100 mt-2 animate-in fade-in slide-in-from-top-2 duration-300">
                  {!isResellerVerified ? (
                    <div className="space-y-3 p-3 bg-white rounded-xl border border-gray-200 shadow-sm">
                      <div className="flex items-center gap-2 mb-1">
                        <ShieldCheck className="text-indigo-600" size={16} />
                        <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Reseller Verification</p>
                      </div>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                        <input 
                          type="email" 
                          value={resellerEmail}
                          onChange={(e) => setResellerEmail(e.target.value)}
                          placeholder="Reseller Email"
                          className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                        <input 
                          type="password" 
                          value={resellerPassword}
                          onChange={(e) => setResellerPassword(e.target.value)}
                          placeholder="Reseller Password"
                          className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                      <button 
                        onClick={handleVerifyReseller}
                        disabled={isVerifying}
                        className="w-full py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-md shadow-indigo-100"
                      >
                        {isVerifying ? 'Verifying...' : 'Verify Account'}
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3 animate-in fade-in duration-300">
                      <div className="flex items-center gap-2 p-2 bg-green-50 text-green-700 rounded-lg border border-green-100">
                        <Check size={16} strokeWidth={3} />
                        <span className="text-xs font-bold">Reseller Verified: {resellerEmail}</span>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Your Profit Margin (₹)</label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">₹</span>
                          <input 
                            type="number" 
                            value={profitMargin}
                            onChange={(e) => setProfitMargin(e.target.value)}
                            placeholder="Enter amount"
                            className="w-full pl-8 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary outline-none transition-all font-bold"
                          />
                        </div>
                        <p className="text-[10px] text-gray-400 italic">This amount will be added to the total order value for your customer.</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="sticky bottom-0 p-4 bg-white border-t mt-auto">
            <button 
              disabled={!selectedMethod}
              onClick={handleContinue}
              className={`w-full py-3 rounded-lg font-bold transition-all ${selectedMethod ? 'bg-primary hover:opacity-90 text-black shadow-md' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
            >
              Continue
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
