import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import Storefront from './pages/Storefront';
import AdminPanel from './pages/AdminPanel';
import ProductDetail from './pages/ProductDetail';
import Account from './pages/Account';
import Cart from './pages/Cart';
import Orders from './pages/Orders';
import Menu from './pages/Menu';
import Wishlist from './pages/Wishlist';
import CategoryProducts from './pages/CategoryProducts';
import PlaceholderPage from './pages/PlaceholderPage';
import BottomNav from './components/BottomNav';
import ResellingWallet from './pages/ResellingWallet';

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-center" richColors />
      <div className="pb-16 md:pb-0">
        <Routes>
          <Route path="/" element={<Storefront />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/account" element={<Account />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/reselling-wallet" element={<ResellingWallet />} />
          <Route path="/buy-again" element={<PlaceholderPage title="Buy Again" />} />
          <Route path="/lists" element={<PlaceholderPage title="Lists" />} />
          <Route path="/category/:id" element={<CategoryProducts />} />
        </Routes>
      </div>
      <BottomNav />
    </BrowserRouter>
  );
}
