export const products = [
  { id: 1, title: "Wireless Noise Cancelling Headphones with 30-Hour Battery Life", price: 23999.00, rating: 4.8, reviews: 12453, image: "https://picsum.photos/seed/headphones/400/400", prime: true },
  { id: 2, title: "Smart Watch with Health Tracking, Heart Rate Monitor, and GPS", price: 15960.00, rating: 4.5, reviews: 8932, image: "https://picsum.photos/seed/smartwatch/400/400", prime: true },
  { id: 3, title: "4K Ultra HD Smart LED TV 55-Inch with Alexa Compatibility", price: 39920.00, rating: 4.6, reviews: 4521, image: "https://picsum.photos/seed/tv/400/400", prime: false },
  { id: 4, title: "Ergonomic Office Chair with Lumbar Support and Adjustable Headrest", price: 12799.00, rating: 4.3, reviews: 2100, image: "https://picsum.photos/seed/chair/400/400", prime: true },
  { id: 5, title: "Programmable Stainless Steel Coffee Maker, 12-Cup", price: 7196.00, rating: 4.7, reviews: 6734, image: "https://picsum.photos/seed/coffee/400/400", prime: true },
  { id: 6, title: "Gaming Laptop 15.6\" 144Hz FHD Display, Intel Core i7, 16GB RAM, 512GB SSD", price: 95999.00, rating: 4.4, reviews: 1543, image: "https://picsum.photos/seed/laptop/400/400", prime: true },
  { id: 7, title: "Adjustable Fitness Dumbbell Set for Home Gym Workouts", price: 3999.00, rating: 4.8, reviews: 982, image: "https://picsum.photos/seed/dumbbell/400/400", prime: false },
  { id: 8, title: "Waterproof Portable Bluetooth Speaker with 24-Hour Playtime", price: 3199.00, rating: 4.5, reviews: 15023, image: "https://picsum.photos/seed/speaker/400/400", prime: true },
  { id: 9, title: "Professional Stand Mixer, 6-Quart Bowl, 10 Speeds", price: 27999.00, rating: 4.9, reviews: 3421, image: "https://picsum.photos/seed/mixer/400/400", prime: true },
  { id: 10, title: "Men's Classic Fit Long-Sleeve Button-Down Poplin Shirt", price: 1992.00, rating: 4.2, reviews: 876, image: "https://picsum.photos/seed/shirt/400/400", prime: true },
];
